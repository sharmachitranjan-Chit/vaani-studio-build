// Writes a synchronous breadcrumb into the native boot log. Used only for
// startup diagnostics; every path is guarded so it can never break the app.
export function bootMark(name: string) {
  try {
    const loaded = require("../../modules/vaani-audio") as {
      default?: { mark?: (value: string) => boolean };
    };
    loaded.default?.mark?.(name);
  } catch {
    // The diagnostic channel is best-effort by design.
  }
}
