module.exports = {
  expo: {
    name: "Vaani Studio",
    slug: "vaani-studio",
    version: "1.0.1",
    orientation: "portrait",
    userInterfaceStyle: "light",
    newArchEnabled: true,
    android: {
      package: "com.moneyclaritytech.vaanistudio",
      versionCode: 2,
      allowBackup: false,
      usesCleartextTraffic: false,
      adaptiveIcon: {
        foregroundImage: "./assets/adaptive-icon.png",
        backgroundColor: "#073B36",
      },
      permissions: ["android.permission.RECORD_AUDIO"],
      blockedPermissions: [
        "android.permission.READ_EXTERNAL_STORAGE",
        "android.permission.WRITE_EXTERNAL_STORAGE",
        "android.permission.READ_MEDIA_IMAGES",
        "android.permission.READ_MEDIA_VIDEO",
        "android.permission.READ_MEDIA_AUDIO",
        "android.permission.SYSTEM_ALERT_WINDOW",
        "android.permission.VIBRATE",
      ],
    },
    icon: "./assets/icon.png",
    splash: {
      backgroundColor: "#F4FBF7",
    },
    plugins: [
      [
        "expo-build-properties",
        {
          android: {
            minSdkVersion: 31,
            compileSdkVersion: 36,
            targetSdkVersion: 36,
            kotlinVersion: "2.1.20",
            enableMinifyInReleaseBuilds: false,
            enableShrinkResourcesInReleaseBuilds: false,
            packagingOptions: {
              pickFirst: ["**/libc++_shared.so"],
            },
          },
        },
      ],
      "./plugins/withArm64Only",
      "./plugins/withNativeKeepRules",
    ],
    extra: {
      modelRepository: "BricksDisplay/chatterbox-multilingual-ONNX-q4",
    },
  },
};
