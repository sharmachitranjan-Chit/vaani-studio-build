# Build Vaani Studio using only your phone

This route uploads one small source ZIP to GitHub. GitHub's computers build the APK; you do not need Android Studio, Termux, or a laptop.

## Before you start

You need a free GitHub account, Chrome on your phone, and the two supplied files:

- `Vaani-Studio-Android-Project.zip`
- `MOBILE_BUILD_WORKFLOW.yml`

The source ZIP does not contain the 830 MB voice model. The app downloads that model after installation.

## Part 1 — Create the repository

1. Open `github.com` in Chrome and sign in.

2. Tap the `+` menu, then **New repository**.

3. Name it `vaani-studio-build`.

4. Choose **Public** for unlimited free standard GitHub Actions minutes. The project contains no voice recording, model, personal script, or secret. If you choose Private, your account's monthly Actions allowance applies.

5. Turn on **Add a README file**, then create the repository.

## Part 2 — Upload the source ZIP

1. In the repository, tap **Add file** → **Upload files**.

2. Select `Vaani-Studio-Android-Project.zip` from Downloads.

3. Keep that exact filename. Tap **Commit changes**.

## Part 3 — Add the build instruction

1. Open `MOBILE_BUILD_WORKFLOW.yml` on your phone and copy all of its text.

2. Return to the repository. Tap **Add file** → **Create new file**.

3. In the filename box, enter exactly:

   `.github/workflows/build.yml`

4. Paste the copied workflow into the editor.

5. Tap **Commit changes**. This first commit starts the build automatically.

## Part 4 — Download the APK

1. Open the repository's **Actions** tab.

2. Tap **Build Vaani Studio from ZIP**. A yellow dot means it is running; a green check means it finished. A first build can take 15–35 minutes.

3. Open the completed run. Under **Artifacts**, tap **Vaani-Studio-APK**.

4. GitHub downloads a small artifact ZIP. Extract it in your phone's Files app.

5. Tap `Vaani-Studio.apk`. Android may ask you to allow Chrome or Files to install unknown apps; allow it for this installation, then turn that permission off again if you prefer.

## Part 5 — First run

1. Open Vaani Studio and accept the responsible-voice statement.

2. Connect to reliable Wi-Fi. Tap **Download offline model** and leave the app open. You can pause and continue later.

3. Read the displayed sentence for 3–6 seconds in a quiet room, or import a 16-bit PCM WAV sample.

4. Tap **Open Vaani Studio**, paste a short test script, and generate. The first generation can take several minutes while the phone opens the model.

5. After setup, switch off Wi-Fi or mobile data if you want to confirm that creation, playback, and sharing work offline.

## Build again later

Open **Actions** → **Build Vaani Studio from ZIP** → **Run workflow**. Each build artifact is retained for 14 days.

## If the build fails

- Confirm the repository root contains `Vaani-Studio-Android-Project.zip` with the exact capitalization.
- Open the failed Actions run and expand the first red step.
- If the failure says quota or billing, use a public repository or wait for your private Actions allowance to reset.
- If an Android dependency download briefly fails, choose **Re-run all jobs**; transient network failures often resolve on retry.

Do not upload your recorded voice or generated WAV files to the repository. Vaani Studio stores them only inside the installed app on your phone.
