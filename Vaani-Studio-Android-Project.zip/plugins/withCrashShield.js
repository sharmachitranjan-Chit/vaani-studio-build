const fs = require("fs");
const path = require("path");
const {
  withAndroidManifest,
  withDangerousMod,
  withMainActivity,
  withMainApplication,
} = require("expo/config-plugins");

const PACKAGE_DIR = ["com", "moneyclaritytech", "vaanistudio"];

// ---------------------------------------------------------------------------
// 1. MainApplication.kt — arm the recorder before anything risky runs and
//    wrap native React initialization so a failure is recorded, not fatal.
// ---------------------------------------------------------------------------

function patchMainApplication(contents) {
  if (contents.includes("CrashShield")) return contents;

  const anchorOnCreate = "  override fun onCreate() {\n    super.onCreate()";
  if (!contents.includes(anchorOnCreate)) {
    throw new Error(
      "withCrashShield: MainApplication.onCreate anchor not found; the Expo template may have changed.",
    );
  }

  let next = contents.replace(
    anchorOnCreate,
    [
      "  override fun onCreate() {",
      "    CrashShield.install(this)",
      "    try {",
      "      com.facebook.react.bridge.ReactMarker.addListener { name, _, _ ->",
      "        when (name) {",
      "          com.facebook.react.bridge.ReactMarkerConstants.CREATE_REACT_CONTEXT_START,",
      "          com.facebook.react.bridge.ReactMarkerConstants.CREATE_REACT_CONTEXT_END,",
      "          com.facebook.react.bridge.ReactMarkerConstants.RUN_JS_BUNDLE_START,",
      "          com.facebook.react.bridge.ReactMarkerConstants.RUN_JS_BUNDLE_END,",
      "          com.facebook.react.bridge.ReactMarkerConstants.CONTENT_APPEARED ->",
      "            CrashShield.step(this, \"MARKER_\" + name.name)",
      "          else -> {}",
      "        }",
      "      }",
      "    } catch (ignored: Throwable) {}",
      "    super.onCreate()",
      "    CrashShield.step(this, \"APPLICATION_SUPER_DONE\")",
    ].join("\n"),
  );

  const anchorLoad = "    loadReactNative(this)\n    ApplicationLifecycleDispatcher.onApplicationCreate(this)";
  if (!next.includes(anchorLoad)) {
    throw new Error(
      "withCrashShield: loadReactNative anchor not found; the Expo template may have changed.",
    );
  }

  next = next.replace(
    anchorLoad,
    [
      "    try {",
      "      loadReactNative(this)",
      "      CrashShield.step(this, \"REACT_NATIVE_LOADED\")",
      "      ApplicationLifecycleDispatcher.onApplicationCreate(this)",
      "      CrashShield.step(this, \"EXPO_MODULES_READY\")",
      "    } catch (t: Throwable) {",
      "      CrashShield.recordBootFailure(this, t)",
      "    }",
    ].join("\n"),
  );

  return next;
}

function patchMainActivity(contents) {
  if (contents.includes("MAIN_ACTIVITY_CREATED")) return contents;
  const anchor = "  override fun onCreate(savedInstanceState: Bundle?) {";
  if (!contents.includes(anchor)) {
    throw new Error(
      "withCrashShield: MainActivity.onCreate anchor not found; the Expo template may have changed.",
    );
  }
  return contents.replace(
    anchor,
    anchor + "\n    CrashShield.step(this, \"MAIN_ACTIVITY_CREATED\")",
  );
}

// ---------------------------------------------------------------------------
// 2. Kotlin sources for the shield itself.
// ---------------------------------------------------------------------------

const CRASH_SHIELD_KT = `package com.moneyclaritytech.vaanistudio

import android.app.Application
import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CrashShield {
  const val CRASH_FILE = "vaani-crash.txt"
  const val BOOT_LOG = "vaani-boot-log.txt"
  const val BOOT_LOG_PREV = "vaani-boot-log-prev.txt"

  @Volatile var bootFailed: Boolean = false
    private set

  fun install(app: Application) {
    try {
      val current = File(app.filesDir, BOOT_LOG)
      val previous = File(app.filesDir, BOOT_LOG_PREV)
      if (current.exists()) {
        current.copyTo(previous, overwrite = true)
      }
      current.writeText("BOOT_START " + now() + "\\n")
    } catch (ignored: Throwable) {}

    val existing = Thread.getDefaultUncaughtExceptionHandler()
    Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
      try {
        writeCrash(app, throwable, "Uncaught on thread " + thread.name)
      } catch (ignored: Throwable) {}
      existing?.uncaughtException(thread, throwable)
        ?: Runtime.getRuntime().halt(1)
    }
    step(app, "SHIELD_ARMED")
  }

  fun step(context: Context, name: String) {
    try {
      File(context.filesDir, BOOT_LOG)
        .appendText(name + " " + now() + "\\n")
    } catch (ignored: Throwable) {}
  }

  fun recordBootFailure(context: Context, throwable: Throwable) {
    bootFailed = true
    writeCrash(context, throwable, "Native startup failure caught in MainApplication")
    step(context, "BOOT_FAILURE_RECORDED")
  }

  fun shouldShowReport(context: Context): Boolean {
    if (bootFailed) return true
    if (File(context.filesDir, CRASH_FILE).exists()) return true
    val previous = File(context.filesDir, BOOT_LOG_PREV)
    if (!previous.exists()) return false
    return try {
      val text = previous.readText()
      text.contains("DISPATCH_TO_MAIN") && !text.contains("REACT_UI_READY")
    } catch (ignored: Throwable) {
      false
    }
  }

  fun reportText(context: Context): String {
    val builder = StringBuilder()
    val crash = File(context.filesDir, CRASH_FILE)
    if (crash.exists()) {
      builder.append(readSafely(crash))
    } else {
      builder.append("No Java-level stack trace was captured.\\n")
      builder.append("The previous launch died at native (C++) level.\\n")
      builder.append("The boot log below shows the last stage reached.\\n")
    }
    builder.append("\\n--- Previous boot log ---\\n")
    builder.append(readSafely(File(context.filesDir, BOOT_LOG_PREV)))
    builder.append("\\n--- Current boot log ---\\n")
    builder.append(readSafely(File(context.filesDir, BOOT_LOG)))
    return builder.toString()
  }

  fun clear(context: Context) {
    try { File(context.filesDir, CRASH_FILE).delete() } catch (ignored: Throwable) {}
    try { File(context.filesDir, BOOT_LOG_PREV).delete() } catch (ignored: Throwable) {}
  }

  private fun writeCrash(context: Context, throwable: Throwable, headline: String) {
    val writer = StringWriter()
    throwable.printStackTrace(PrintWriter(writer))
    val text = buildString {
      append("Vaani Studio crash report\\n")
      append(headline).append("\\n")
      append("Time: ").append(now()).append("\\n")
      append("Device: ").append(Build.MANUFACTURER).append(" ")
      append(Build.MODEL).append("\\n")
      append("Android: ").append(Build.VERSION.RELEASE)
      append(" (API ").append(Build.VERSION.SDK_INT).append(")\\n")
      append("ABIs: ").append(Build.SUPPORTED_ABIS.joinToString()).append("\\n\\n")
      append(writer.toString())
    }
    try {
      File(context.filesDir, CRASH_FILE).writeText(text)
    } catch (ignored: Throwable) {}
  }

  private fun readSafely(file: File): String {
    return try {
      if (file.exists()) file.readText() else "(missing)\\n"
    } catch (ignored: Throwable) {
      "(unreadable)\\n"
    }
  }

  private fun now(): String {
    return SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
  }
}
`;

const DISPATCH_ACTIVITY_KT = `package com.moneyclaritytech.vaanistudio

import android.app.Activity
import android.content.Intent
import android.os.Bundle

class LaunchDispatchActivity : Activity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    val target = if (CrashShield.shouldShowReport(this)) {
      CrashShield.step(this, "DISPATCH_TO_REPORT")
      Intent(this, CrashReportActivity::class.java)
    } else {
      CrashShield.step(this, "DISPATCH_TO_MAIN")
      Intent(this, MainActivity::class.java)
    }
    startActivity(target)
    finish()
  }
}
`;

const REPORT_ACTIVITY_KT = `package com.moneyclaritytech.vaanistudio

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class CrashReportActivity : Activity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    val report = CrashShield.reportText(this)
    val density = resources.displayMetrics.density
    fun dp(value: Int): Int = (value * density).toInt()

    val root = LinearLayout(this)
    root.orientation = LinearLayout.VERTICAL
    root.setBackgroundColor(Color.parseColor("#F4FBF7"))
    root.setPadding(dp(20), dp(40), dp(20), dp(20))

    val title = TextView(this)
    title.text = "Vaani Studio black box"
    title.textSize = 24f
    title.setTypeface(null, Typeface.BOLD)
    title.setTextColor(Color.parseColor("#073B36"))
    root.addView(title)

    val subtitle = TextView(this)
    subtitle.text =
      "The previous launch could not finish. The recorded reason is below. " +
      "Tap Copy full report and share it with the developer."
    subtitle.textSize = 15f
    subtitle.setTextColor(Color.parseColor("#365B55"))
    subtitle.setPadding(0, dp(8), 0, dp(12))
    root.addView(subtitle)

    val scroll = ScrollView(this)
    scroll.setBackgroundColor(Color.parseColor("#E4F4EC"))
    scroll.setPadding(dp(12), dp(12), dp(12), dp(12))
    val body = TextView(this)
    body.text = report
    body.textSize = 12f
    body.setTextIsSelectable(true)
    body.typeface = Typeface.MONOSPACE
    body.setTextColor(Color.parseColor("#163E38"))
    scroll.addView(body)
    val scrollParams = LinearLayout.LayoutParams(
      LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
    root.addView(scroll, scrollParams)

    fun makeButton(label: String, background: String, foreground: String): Button {
      val button = Button(this)
      button.text = label
      button.isAllCaps = false
      button.textSize = 16f
      button.setTextColor(Color.parseColor(foreground))
      button.setBackgroundColor(Color.parseColor(background))
      val params = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT)
      params.topMargin = dp(10)
      button.layoutParams = params
      button.gravity = Gravity.CENTER
      button.setPadding(0, dp(12), 0, dp(12))
      return button
    }

    val copyButton = makeButton("Copy full report", "#073B36", "#FFFFFF")
    copyButton.setOnClickListener {
      val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
      clipboard.setPrimaryClip(ClipData.newPlainText("Vaani Studio crash report", report))
      Toast.makeText(this, "Report copied", Toast.LENGTH_SHORT).show()
    }
    root.addView(copyButton)

    val retryButton = makeButton("Clear and try the app again", "#F6B73C", "#073B36")
    retryButton.setOnClickListener {
      CrashShield.clear(this)
      startActivity(Intent(this, MainActivity::class.java))
      finish()
    }
    root.addView(retryButton)

    setContentView(root)
  }
}
`;

function withShieldSources(config) {
  return withDangerousMod(config, [
    "android",
    async (nextConfig) => {
      const dir = path.join(
        nextConfig.modRequest.platformProjectRoot,
        "app",
        "src",
        "main",
        "java",
        ...PACKAGE_DIR,
      );
      await fs.promises.mkdir(dir, { recursive: true });
      await fs.promises.writeFile(path.join(dir, "CrashShield.kt"), CRASH_SHIELD_KT);
      await fs.promises.writeFile(
        path.join(dir, "LaunchDispatchActivity.kt"),
        DISPATCH_ACTIVITY_KT,
      );
      await fs.promises.writeFile(
        path.join(dir, "CrashReportActivity.kt"),
        REPORT_ACTIVITY_KT,
      );
      return nextConfig;
    },
  ]);
}

// ---------------------------------------------------------------------------
// 3. Manifest — the dispatcher becomes the launcher; the report screen is
//    registered as a plain internal activity.
// ---------------------------------------------------------------------------

function withShieldManifest(config) {
  return withAndroidManifest(config, (nextConfig) => {
    const application = nextConfig.modResults.manifest.application?.[0];
    if (!application) {
      throw new Error("withCrashShield: no <application> element in the manifest.");
    }
    const activities = application.activity || [];
    const main = activities.find(
      (item) => item.$["android:name"] === ".MainActivity",
    );
    if (!main) {
      throw new Error("withCrashShield: .MainActivity not found in the manifest.");
    }

    const launcherFilter = [
      {
        action: [{ $: { "android:name": "android.intent.action.MAIN" } }],
        category: [{ $: { "android:name": "android.intent.category.LAUNCHER" } }],
      },
    ];

    // MainActivity keeps everything except the launcher role.
    if (main["intent-filter"]) {
      main["intent-filter"] = main["intent-filter"].filter((filter) => {
        const categories = filter.category || [];
        return !categories.some(
          (item) =>
            item.$["android:name"] === "android.intent.category.LAUNCHER",
        );
      });
      if (main["intent-filter"].length === 0) delete main["intent-filter"];
    }

    const hasDispatcher = activities.some(
      (item) => item.$["android:name"] === ".LaunchDispatchActivity",
    );
    if (!hasDispatcher) {
      activities.push({
        $: {
          "android:name": ".LaunchDispatchActivity",
          "android:exported": "true",
          "android:theme": "@style/Theme.App.SplashScreen",
          "android:screenOrientation": "portrait",
        },
        "intent-filter": launcherFilter,
      });
      activities.push({
        $: {
          "android:name": ".CrashReportActivity",
          "android:exported": "false",
          "android:theme": "@style/AppTheme",
          "android:screenOrientation": "portrait",
        },
      });
    }
    application.activity = activities;
    return nextConfig;
  });
}

module.exports = function withCrashShield(config) {
  config = withMainApplication(config, (nextConfig) => {
    nextConfig.modResults.contents = patchMainApplication(
      nextConfig.modResults.contents,
    );
    return nextConfig;
  });
  config = withMainActivity(config, (nextConfig) => {
    nextConfig.modResults.contents = patchMainActivity(
      nextConfig.modResults.contents,
    );
    return nextConfig;
  });
  config = withShieldSources(config);
  config = withShieldManifest(config);
  return config;
};
