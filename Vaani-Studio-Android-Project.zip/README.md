# Vaani Studio 3.0 — Native Android

Fully offline text-to-speech studio for making voice-over audio for videos.

Built as a pure native Android app in Kotlin. No React Native, no Expo,
no JavaScript engine, no experimental libraries — only stable Android
framework APIs that every phone ships with.

## What it does
- Write or paste a script (Hindi, English, or any installed language)
- Pick any installed voice; offline voices are marked
- Adjust speed and pitch, preview instantly
- Export the full script to a WAV file, however long — the app splits it
  into parts, generates each, and joins them seamlessly
- The WAV is saved to Downloads › VaaniStudio and can be shared anywhere
- Save and reload scripts inside the app
- If the app ever crashes, the report appears on the next launch

## One-time setup (because the build system changed)
The old workflow built a React Native app; this is a Gradle-only build.
Update the workflow file once, from your phone:

1. Open the repository on GitHub → `.github/workflows/build-android.yml`
2. Tap the pencil (Edit) icon
3. Select all, delete, and paste the contents of
   `.github/workflows/build-android.yml` from this ZIP
   (also copied below in `WORKFLOW_COPY_PASTE.txt` for convenience)
4. Commit the change (this run may fail — ignore it)
5. Upload this ZIP to the repository root as
   `Vaani-Studio-Android-Project.zip` (replacing the old one)
6. The build runs automatically (~5 minutes) and produces the APK artifact

## Changelog
### 3.0.0
- Complete rebuild as a native Android app on the built-in speech engine,
  after the previous React Native app was killed at native level on the
  target device regardless of framework version.
