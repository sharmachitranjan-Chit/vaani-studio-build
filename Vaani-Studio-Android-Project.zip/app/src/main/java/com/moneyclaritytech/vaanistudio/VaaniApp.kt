package com.moneyclaritytech.vaanistudio

import android.app.Application
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class VaaniApp : Application() {

    override fun onCreate() {
        super.onCreate()
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                writeCrash(thread.name, throwable)
            } catch (ignored: Throwable) {
            }
            previous?.uncaughtException(thread, throwable)
                ?: Runtime.getRuntime().halt(1)
        }
    }

    private fun writeCrash(threadName: String, throwable: Throwable) {
        val writer = StringWriter()
        throwable.printStackTrace(PrintWriter(writer))
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
            .format(Date())
        val text = buildString {
            append("Vaani Studio crash report\n")
            append("Time: ").append(stamp).append("\n")
            append("Thread: ").append(threadName).append("\n")
            append("Device: ").append(Build.MANUFACTURER).append(" ")
            append(Build.MODEL).append("\n")
            append("Android: ").append(Build.VERSION.RELEASE)
            append(" (API ").append(Build.VERSION.SDK_INT).append(")\n\n")
            append(writer.toString())
        }
        File(filesDir, CRASH_FILE).writeText(text)
    }

    companion object {
        const val CRASH_FILE = "vaani-crash.txt"
    }
}
