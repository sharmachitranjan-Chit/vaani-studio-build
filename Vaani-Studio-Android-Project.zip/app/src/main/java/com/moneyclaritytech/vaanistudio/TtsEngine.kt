package com.moneyclaritytech.vaanistudio

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Thin, safe wrapper around Android's built-in TextToSpeech engine.
 * Everything here uses only stable framework APIs.
 */
class TtsEngine(context: Context, private val onReady: (Boolean) -> Unit) {

    private var tts: TextToSpeech? = null
    var ready = false
        private set

    private val latches = ConcurrentHashMap<String, CountDownLatch>()
    private val failures = ConcurrentHashMap<String, Boolean>()

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}

                    override fun onDone(utteranceId: String?) {
                        if (utteranceId != null) {
                            failures[utteranceId] = false
                            latches.remove(utteranceId)?.countDown()
                        }
                    }

                    @Deprecated("Framework still calls this on older engines")
                    override fun onError(utteranceId: String?) {
                        if (utteranceId != null) {
                            failures[utteranceId] = true
                            latches.remove(utteranceId)?.countDown()
                        }
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        if (utteranceId != null) {
                            failures[utteranceId] = true
                            latches.remove(utteranceId)?.countDown()
                        }
                    }
                })
            }
            onReady(ready)
        }
    }

    /** All voices installed on the device, best (offline, high quality) first. */
    fun voices(): List<Voice> {
        val engine = tts ?: return emptyList()
        return try {
            (engine.voices ?: emptySet())
                .filterNotNull()
                .filter { !it.isNetworkConnectionRequired || it.features?.contains(
                    TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) != true }
                .sortedWith(
                    compareBy(
                        { it.isNetworkConnectionRequired },
                        { it.locale.displayLanguage },
                        { -it.quality },
                        { it.name },
                    ),
                )
        } catch (t: Throwable) {
            emptyList()
        }
    }

    fun applySettings(voice: Voice?, rate: Float, pitch: Float) {
        val engine = tts ?: return
        try {
            if (voice != null) engine.voice = voice
            engine.setSpeechRate(rate)
            engine.setPitch(pitch)
        } catch (ignored: Throwable) {
        }
    }

    fun preview(text: String): Boolean {
        val engine = tts ?: return false
        if (!ready) return false
        val safe = if (text.length > maxChunkLength()) {
            text.substring(0, maxChunkLength())
        } else {
            text
        }
        return engine.speak(safe, TextToSpeech.QUEUE_FLUSH, Bundle(), "preview") ==
            TextToSpeech.SUCCESS
    }

    fun stop() {
        try {
            tts?.stop()
        } catch (ignored: Throwable) {
        }
    }

    /**
     * Renders one chunk of text into a WAV file. Blocks the calling thread
     * (call from a background thread only) until the engine finishes.
     */
    fun synthesizeChunk(text: String, output: File, timeoutSeconds: Long): Boolean {
        val engine = tts ?: return false
        if (!ready) return false
        val id = "chunk-" + System.nanoTime()
        val latch = CountDownLatch(1)
        latches[id] = latch
        failures.remove(id)
        val queued = engine.synthesizeToFile(text, Bundle(), output, id)
        if (queued != TextToSpeech.SUCCESS) {
            latches.remove(id)
            return false
        }
        val finished = try {
            latch.await(timeoutSeconds, TimeUnit.SECONDS)
        } catch (interrupted: InterruptedException) {
            false
        }
        if (!finished) {
            latches.remove(id)
            return false
        }
        return failures[id] != true && output.exists() && output.length() > 44
    }

    fun maxChunkLength(): Int {
        val reported = try {
            TextToSpeech.getMaxSpeechInputLength()
        } catch (t: Throwable) {
            4000
        }
        // Stay well under the engine limit for safety.
        return (reported - 500).coerceIn(1500, 3500)
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (ignored: Throwable) {
        }
        tts = null
        ready = false
    }

    companion object {
        /** Splits a long script into sentence-aligned chunks the engine accepts. */
        fun splitIntoChunks(text: String, maxLength: Int): List<String> {
            val trimmed = text.trim()
            if (trimmed.isEmpty()) return emptyList()
            if (trimmed.length <= maxLength) return listOf(trimmed)

            val sentences = ArrayList<String>()
            val current = StringBuilder()
            for (ch in trimmed) {
                current.append(ch)
                if (ch == '।' || ch == '.' || ch == '!' || ch == '?' || ch == '\n') {
                    sentences.add(current.toString())
                    current.setLength(0)
                }
            }
            if (current.isNotEmpty()) sentences.add(current.toString())

            val chunks = ArrayList<String>()
            val buffer = StringBuilder()
            for (sentence in sentences) {
                if (sentence.length > maxLength) {
                    // A single monster sentence: hard-split it.
                    if (buffer.isNotEmpty()) {
                        chunks.add(buffer.toString())
                        buffer.setLength(0)
                    }
                    var start = 0
                    while (start < sentence.length) {
                        val end = (start + maxLength).coerceAtMost(sentence.length)
                        chunks.add(sentence.substring(start, end))
                        start = end
                    }
                    continue
                }
                if (buffer.length + sentence.length > maxLength) {
                    chunks.add(buffer.toString())
                    buffer.setLength(0)
                }
                buffer.append(sentence)
            }
            if (buffer.isNotEmpty()) chunks.add(buffer.toString())
            return chunks.map { it.trim() }.filter { it.isNotEmpty() }
        }
    }
}
