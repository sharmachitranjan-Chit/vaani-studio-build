package com.moneyclaritytech.vaanistudio

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class CrashReportActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val file = File(filesDir, VaaniApp.CRASH_FILE)
        val report = try {
            if (file.exists()) file.readText() else "No crash report found."
        } catch (t: Throwable) {
            "The crash report could not be read."
        }

        val density = resources.displayMetrics.density
        fun dp(value: Int): Int = (value * density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#F4FBF7"))
        root.setPadding(dp(20), dp(40), dp(20), dp(20))

        val title = TextView(this)
        title.text = "Last crash report"
        title.textSize = 24f
        title.setTypeface(null, Typeface.BOLD)
        title.setTextColor(Color.parseColor("#073B36"))
        root.addView(title)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#E4F4EC"))
        scroll.setPadding(dp(12), dp(12), dp(12), dp(12))
        val body = TextView(this)
        body.text = report
        body.textSize = 12f
        body.setTextIsSelectable(true)
        body.typeface = Typeface.MONOSPACE
        body.setTextColor(Color.parseColor("#163E38"))
        scroll.addView(body)
        val scrollParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        scrollParams.topMargin = dp(12)
        root.addView(scroll, scrollParams)

        fun makeButton(label: String, background: String, foreground: String): Button {
            val button = Button(this)
            button.text = label
            button.isAllCaps = false
            button.textSize = 16f
            button.setTextColor(Color.parseColor(foreground))
            button.setBackgroundColor(Color.parseColor(background))
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT)
            params.topMargin = dp(10)
            button.layoutParams = params
            return button
        }

        val copy = makeButton("Copy report", "#073B36", "#FFFFFF")
        copy.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Vaani Studio crash", report))
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        }
        root.addView(copy)

        val clear = makeButton("Clear and close", "#F6B73C", "#073B36")
        clear.setOnClickListener {
            try {
                file.delete()
            } catch (ignored: Throwable) {
            }
            finish()
        }
        root.addView(clear)

        setContentView(root)
    }
}
