package com.moneyclaritytech.vaanistudio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Saved scripts, stored as a small JSON file in app-private storage. */
class ScriptStore(context: Context) {

    private val file = File(context.filesDir, "scripts.json")

    data class Script(val name: String, val text: String, val updated: Long)

    fun all(): List<Script> {
        if (!file.exists()) return emptyList()
        return try {
            val array = JSONArray(file.readText())
            val list = ArrayList<Script>()
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                list.add(
                    Script(
                        item.optString("name"),
                        item.optString("text"),
                        item.optLong("updated"),
                    ),
                )
            }
            list.sortedByDescending { it.updated }
        } catch (t: Throwable) {
            emptyList()
        }
    }

    fun save(name: String, text: String) {
        val existing = all().filter { it.name != name }
        val next = ArrayList(existing)
        next.add(0, Script(name, text, System.currentTimeMillis()))
        write(next)
    }

    fun delete(name: String) {
        write(all().filter { it.name != name })
    }

    private fun write(scripts: List<Script>) {
        try {
            val array = JSONArray()
            for (script in scripts) {
                val item = JSONObject()
                item.put("name", script.name)
                item.put("text", script.text)
                item.put("updated", script.updated)
                array.put(item)
            }
            file.writeText(array.toString())
        } catch (ignored: Throwable) {
        }
    }
}
