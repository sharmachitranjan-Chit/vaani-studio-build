package com.moneyclaritytech.vaanistudio

import java.io.File
import java.io.RandomAccessFile

/**
 * Joins several WAV files (produced by the same voice, so identical format)
 * into one file, streaming the audio data so memory stays flat even for
 * very long scripts.
 */
object WavMerger {

    private data class WavInfo(
        val channels: Int,
        val sampleRate: Int,
        val bitsPerSample: Int,
        val dataOffset: Long,
        val dataSize: Long,
    )

    fun merge(inputs: List<File>, output: File): Boolean {
        if (inputs.isEmpty()) return false
        val infos = ArrayList<WavInfo>()
        for (file in inputs) {
            val info = inspect(file) ?: return false
            infos.add(info)
        }
        val first = infos[0]
        for (info in infos) {
            if (info.channels != first.channels ||
                info.sampleRate != first.sampleRate ||
                info.bitsPerSample != first.bitsPerSample
            ) {
                return false
            }
        }
        val totalData = infos.sumOf { it.dataSize }
        if (totalData <= 0 || totalData > Int.MAX_VALUE - 100) return false

        output.parentFile?.mkdirs()
        RandomAccessFile(output, "rw").use { out ->
            out.setLength(0)
            writeHeader(out, first, totalData.toInt())
            val buffer = ByteArray(64 * 1024)
            for ((index, file) in inputs.withIndex()) {
                val info = infos[index]
                RandomAccessFile(file, "r").use { input ->
                    input.seek(info.dataOffset)
                    var remaining = info.dataSize
                    while (remaining > 0) {
                        val toRead = minOf(remaining, buffer.size.toLong()).toInt()
                        val read = input.read(buffer, 0, toRead)
                        if (read <= 0) return false
                        out.write(buffer, 0, read)
                        remaining -= read
                    }
                }
            }
        }
        return true
    }

    private fun inspect(file: File): WavInfo? {
        RandomAccessFile(file, "r").use { input ->
            if (input.length() < 44) return null
            val riff = ByteArray(4)
            input.readFully(riff)
            if (String(riff) != "RIFF") return null
            input.skipBytes(4)
            val wave = ByteArray(4)
            input.readFully(wave)
            if (String(wave) != "WAVE") return null

            var channels = 0
            var sampleRate = 0
            var bits = 0
            var dataOffset = -1L
            var dataSize = -1L

            while (input.filePointer + 8 <= input.length()) {
                val id = ByteArray(4)
                input.readFully(id)
                val size = readIntLe(input)
                val chunkStart = input.filePointer
                when (String(id)) {
                    "fmt " -> {
                        if (size < 16) return null
                        input.skipBytes(2) // audio format
                        channels = readShortLe(input)
                        sampleRate = readIntLe(input)
                        input.skipBytes(6) // byte rate + block align
                        bits = readShortLe(input)
                    }
                    "data" -> {
                        dataOffset = chunkStart
                        dataSize = size.toLong() and 0xFFFFFFFFL
                        // The final chunk's declared size can exceed the real
                        // file on some engines; clamp to what exists.
                        val available = input.length() - chunkStart
                        if (dataSize > available) dataSize = available
                    }
                }
                if (dataOffset >= 0 && channels > 0) break
                val advance = size.toLong() + (size.toLong() % 2)
                input.seek(chunkStart + advance)
            }

            if (channels <= 0 || sampleRate <= 0 || bits <= 0) return null
            if (dataOffset < 0 || dataSize <= 0) return null
            return WavInfo(channels, sampleRate, bits, dataOffset, dataSize)
        }
    }

    private fun writeHeader(out: RandomAccessFile, info: WavInfo, dataSize: Int) {
        val byteRate = info.sampleRate * info.channels * info.bitsPerSample / 8
        val blockAlign = info.channels * info.bitsPerSample / 8
        out.write("RIFF".toByteArray())
        writeIntLe(out, 36 + dataSize)
        out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray())
        writeIntLe(out, 16)
        writeShortLe(out, 1) // PCM
        writeShortLe(out, info.channels)
        writeIntLe(out, info.sampleRate)
        writeIntLe(out, byteRate)
        writeShortLe(out, blockAlign)
        writeShortLe(out, info.bitsPerSample)
        out.write("data".toByteArray())
        writeIntLe(out, dataSize)
    }

    private fun readIntLe(input: RandomAccessFile): Int {
        val b0 = input.read()
        val b1 = input.read()
        val b2 = input.read()
        val b3 = input.read()
        return (b0 and 0xFF) or ((b1 and 0xFF) shl 8) or
            ((b2 and 0xFF) shl 16) or ((b3 and 0xFF) shl 24)
    }

    private fun readShortLe(input: RandomAccessFile): Int {
        val b0 = input.read()
        val b1 = input.read()
        return (b0 and 0xFF) or ((b1 and 0xFF) shl 8)
    }

    private fun writeIntLe(out: RandomAccessFile, value: Int) {
        out.write(value and 0xFF)
        out.write((value shr 8) and 0xFF)
        out.write((value shr 16) and 0xFF)
        out.write((value shr 24) and 0xFF)
    }

    private fun writeShortLe(out: RandomAccessFile, value: Int) {
        out.write(value and 0xFF)
        out.write((value shr 8) and 0xFF)
    }
}
