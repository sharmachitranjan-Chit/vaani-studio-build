package com.moneyclaritytech.vaanistudio

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.speech.tts.Voice
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private val deep = Color.parseColor("#073B36")
    private val cream = Color.parseColor("#F4FBF7")
    private val card = Color.parseColor("#FFFFFF")
    private val mint = Color.parseColor("#E4F4EC")
    private val amber = Color.parseColor("#F6B73C")
    private val ink = Color.parseColor("#163E38")
    private val sub = Color.parseColor("#365B55")

    private var engine: TtsEngine? = null
    private var voiceOptions: List<Voice> = emptyList()
    private var selectedVoice: Voice? = null
    private var rate = 1.0f
    private var pitch = 1.0f
    private var exporting = false
    private var player: MediaPlayer? = null
    private var lastExport: File? = null
    private var lastExportUri: Uri? = null

    private lateinit var store: ScriptStore
    private lateinit var scriptInput: EditText
    private lateinit var charCount: TextView
    private lateinit var voiceStatus: TextView
    private lateinit var voiceSpinner: Spinner
    private lateinit var rateLabel: TextView
    private lateinit var pitchLabel: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var progressText: TextView
    private lateinit var resultCard: LinearLayout
    private lateinit var resultText: TextView
    private lateinit var playButton: Button
    private lateinit var exportButton: Button

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int): GradientDrawable {
        val drawable = GradientDrawable()
        drawable.setColor(color)
        drawable.cornerRadius = dp(radius).toFloat()
        return drawable
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ScriptStore(this)
        setContentView(buildUi())
        engine = TtsEngine(this) { ready ->
            runOnUiThread {
                if (ready) {
                    voiceStatus.text = "Speech engine ready."
                    refreshVoices()
                } else {
                    voiceStatus.text =
                        "No speech engine found. Tap Voice settings to install " +
                        "Google Speech Services, then tap Refresh."
                }
            }
        }
    }

    // ------------------------------------------------------------------ UI

    private fun buildUi(): View {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(cream)
        scroll.isFillViewport = true

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(18), dp(28), dp(18), dp(28))
        scroll.addView(root)

        if (File(filesDir, VaaniApp.CRASH_FILE).exists()) {
            root.addView(crashBanner())
        }

        val title = TextView(this)
        title.text = "Vaani Studio"
        title.textSize = 30f
        title.setTypeface(null, Typeface.BOLD)
        title.setTextColor(deep)
        root.addView(title)

        val subtitle = TextView(this)
        subtitle.text = "Offline text-to-speech for your videos"
        subtitle.textSize = 15f
        subtitle.setTextColor(sub)
        subtitle.setPadding(0, dp(2), 0, dp(14))
        root.addView(subtitle)

        // ---- Script card
        root.addView(sectionCard().also { section ->
            section.addView(sectionTitle("Your script"))
            scriptInput = EditText(this)
            scriptInput.hint = "Type or paste your script here…"
            scriptInput.setHintTextColor(sub)
            scriptInput.setTextColor(ink)
            scriptInput.textSize = 16f
            scriptInput.gravity = Gravity.TOP
            scriptInput.minLines = 6
            scriptInput.maxLines = 14
            scriptInput.inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            scriptInput.imeOptions = EditorInfo.IME_FLAG_NO_ENTER_ACTION
            scriptInput.background = rounded(mint, 10)
            scriptInput.setPadding(dp(12), dp(12), dp(12), dp(12))
            section.addView(scriptInput)

            charCount = TextView(this)
            charCount.text = "0 characters"
            charCount.textSize = 12f
            charCount.setTextColor(sub)
            charCount.setPadding(0, dp(6), 0, 0)
            section.addView(charCount)

            scriptInput.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(
                    s: CharSequence?, start: Int, count: Int, after: Int) {}

                override fun onTextChanged(
                    s: CharSequence?, start: Int, before: Int, count: Int) {}

                override fun afterTextChanged(s: Editable?) {
                    charCount.text = "${s?.length ?: 0} characters"
                }
            })

            section.addView(buttonRow(
                secondaryButton("Save script") { saveScriptDialog() },
                secondaryButton("My scripts") { openScriptsDialog() },
            ))
        })

        // ---- Voice card
        root.addView(sectionCard().also { section ->
            section.addView(sectionTitle("Voice"))
            voiceStatus = TextView(this)
            voiceStatus.text = "Starting speech engine…"
            voiceStatus.textSize = 13f
            voiceStatus.setTextColor(sub)
            section.addView(voiceStatus)

            voiceSpinner = Spinner(this)
            voiceSpinner.background = rounded(mint, 10)
            voiceSpinner.setPadding(dp(10), dp(10), dp(10), dp(10))
            val spinnerParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT)
            spinnerParams.topMargin = dp(8)
            section.addView(voiceSpinner, spinnerParams)
            voiceSpinner.onItemSelectedListener =
                object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(
                        parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                        selectedVoice = voiceOptions.getOrNull(position)
                    }

                    override fun onNothingSelected(parent: AdapterView<*>?) {
                        selectedVoice = null
                    }
                }

            section.addView(buttonRow(
                secondaryButton("Refresh voices") { refreshVoices() },
                secondaryButton("Voice settings") { openTtsSettings() },
            ))

            val hint = TextView(this)
            hint.text = "Voices marked Offline work without internet. For more " +
                "Hindi voices, open Voice settings and download Hindi voice data."
            hint.textSize = 12f
            hint.setTextColor(sub)
            hint.setPadding(0, dp(8), 0, 0)
            section.addView(hint)
        })

        // ---- Delivery card
        root.addView(sectionCard().also { section ->
            section.addView(sectionTitle("Delivery"))
            rateLabel = TextView(this)
            rateLabel.setTextColor(ink)
            rateLabel.textSize = 14f
            section.addView(rateLabel)
            section.addView(slider(50) { value ->
                rate = value
                rateLabel.text = "Speed: ${format(value)}×"
            })

            pitchLabel = TextView(this)
            pitchLabel.setTextColor(ink)
            pitchLabel.textSize = 14f
            pitchLabel.setPadding(0, dp(10), 0, 0)
            section.addView(pitchLabel)
            section.addView(slider(50) { value ->
                pitch = value
                pitchLabel.text = "Pitch: ${format(value)}×"
            })

            section.addView(buttonRow(
                secondaryButton("Preview") { preview() },
                secondaryButton("Stop") { engine?.stop() },
            ))
        })

        // ---- Export
        exportButton = Button(this)
        exportButton.text = "Export full audio (WAV)"
        exportButton.isAllCaps = false
        exportButton.textSize = 17f
        exportButton.setTypeface(null, Typeface.BOLD)
        exportButton.setTextColor(deep)
        exportButton.background = rounded(amber, 12)
        exportButton.setPadding(0, dp(14), 0, dp(14))
        val exportParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT)
        exportParams.topMargin = dp(6)
        exportButton.layoutParams = exportParams
        exportButton.setOnClickListener { export() }
        root.addView(exportButton)

        progressBar = ProgressBar(
            this, null, android.R.attr.progressBarStyleHorizontal)
        progressBar.visibility = View.GONE
        val progressParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT)
        progressParams.topMargin = dp(10)
        root.addView(progressBar, progressParams)

        progressText = TextView(this)
        progressText.textSize = 13f
        progressText.setTextColor(sub)
        progressText.visibility = View.GONE
        root.addView(progressText)

        // ---- Result card
        resultCard = sectionCard()
        resultCard.visibility = View.GONE
        resultCard.addView(sectionTitle("Your audio is ready"))
        resultText = TextView(this)
        resultText.textSize = 13f
        resultText.setTextColor(ink)
        resultCard.addView(resultText)
        playButton = secondaryButton("Play") { togglePlayback() }
        resultCard.addView(buttonRow(
            playButton,
            secondaryButton("Share") { shareExport() },
        ))
        root.addView(resultCard)

        val footer = TextView(this)
        footer.text = "Vaani Studio 3.0.0 • Fully offline • Native Android"
        footer.textSize = 11f
        footer.setTextColor(sub)
        footer.gravity = Gravity.CENTER
        footer.setPadding(0, dp(20), 0, 0)
        root.addView(footer)

        return scroll
    }

    private fun crashBanner(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.background = rounded(Color.parseColor("#FDECDA"), 10)
        row.setPadding(dp(12), dp(10), dp(12), dp(10))
        val message = TextView(this)
        message.text = "The last session ended with an error."
        message.textSize = 13f
        message.setTextColor(ink)
        val messageParams = LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        row.addView(message, messageParams)
        val view = TextView(this)
        view.text = "View"
        view.setTypeface(null, Typeface.BOLD)
        view.setTextColor(deep)
        view.setPadding(dp(12), 0, 0, 0)
        view.setOnClickListener {
            startActivity(Intent(this, CrashReportActivity::class.java))
        }
        row.addView(view)
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT)
        params.bottomMargin = dp(12)
        row.layoutParams = params
        return row
    }

    private fun sectionCard(): LinearLayout {
        val section = LinearLayout(this)
        section.orientation = LinearLayout.VERTICAL
        section.background = rounded(card, 14)
        section.setPadding(dp(14), dp(14), dp(14), dp(14))
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT)
        params.bottomMargin = dp(12)
        section.layoutParams = params
        return section
    }

    private fun sectionTitle(text: String): TextView {
        val view = TextView(this)
        view.text = text
        view.textSize = 16f
        view.setTypeface(null, Typeface.BOLD)
        view.setTextColor(deep)
        view.setPadding(0, 0, 0, dp(8))
        return view
    }

    private fun secondaryButton(label: String, onClick: () -> Unit): Button {
        val button = Button(this)
        button.text = label
        button.isAllCaps = false
        button.textSize = 14f
        button.setTextColor(cream)
        button.background = rounded(deep, 10)
        button.setOnClickListener { onClick() }
        return button
    }

    private fun buttonRow(vararg buttons: Button): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val rowParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT)
        rowParams.topMargin = dp(10)
        row.layoutParams = rowParams
        for ((index, button) in buttons.withIndex()) {
            val params = LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            if (index > 0) params.leftMargin = dp(8)
            row.addView(button, params)
        }
        return row
    }

    private fun slider(initial: Int, onValue: (Float) -> Unit): SeekBar {
        val bar = SeekBar(this)
        bar.max = 150
        bar.progress = initial
        onValue(0.5f + initial / 100f)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(
                seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                onValue(0.5f + progress / 100f)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        return bar
    }

    private fun format(value: Float): String =
        String.format(Locale.US, "%.2f", value)

    // ------------------------------------------------------------- Voices

    private fun refreshVoices() {
        val current = engine ?: return
        if (!current.ready) return
        voiceOptions = current.voices()
        if (voiceOptions.isEmpty()) {
            voiceStatus.text = "No voices found yet. Open Voice settings, " +
                "install voice data, then tap Refresh."
            voiceSpinner.adapter = ArrayAdapter(
                this, android.R.layout.simple_spinner_dropdown_item,
                listOf("No voices available"))
            return
        }
        voiceStatus.text = "${voiceOptions.size} voices available."
        val labels = voiceOptions.map { voice ->
            val offline = if (voice.isNetworkConnectionRequired) "Online" else "Offline"
            "${voice.locale.displayName} • $offline"
        }
        voiceSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, labels)
        val preferred = voiceOptions.indexOfFirst {
            it.locale.language == "hi" && !it.isNetworkConnectionRequired
        }.takeIf { it >= 0 }
            ?: voiceOptions.indexOfFirst {
                it.locale.language == "en" && it.locale.country == "IN" &&
                    !it.isNetworkConnectionRequired
            }.takeIf { it >= 0 }
            ?: 0
        voiceSpinner.setSelection(preferred)
        selectedVoice = voiceOptions.getOrNull(preferred)
    }

    private fun openTtsSettings() {
        try {
            startActivity(Intent("com.android.settings.TTS_SETTINGS"))
        } catch (t: Throwable) {
            Toast.makeText(this,
                "Voice settings could not be opened on this phone.",
                Toast.LENGTH_LONG).show()
        }
    }

    // ------------------------------------------------------------ Actions

    private fun preview() {
        val current = engine ?: return
        val text = scriptInput.text.toString().trim()
        if (text.isEmpty()) {
            Toast.makeText(this, "Write a script first.", Toast.LENGTH_SHORT).show()
            return
        }
        if (!current.ready) {
            Toast.makeText(this, "The speech engine is not ready yet.",
                Toast.LENGTH_SHORT).show()
            return
        }
        current.applySettings(selectedVoice, rate, pitch)
        current.preview(text)
    }

    private fun export() {
        if (exporting) return
        val current = engine ?: return
        val text = scriptInput.text.toString().trim()
        if (text.isEmpty()) {
            Toast.makeText(this, "Write a script first.", Toast.LENGTH_SHORT).show()
            return
        }
        if (!current.ready) {
            Toast.makeText(this, "The speech engine is not ready yet.",
                Toast.LENGTH_SHORT).show()
            return
        }
        exporting = true
        exportButton.isEnabled = false
        exportButton.text = "Exporting…"
        stopPlayback()
        resultCard.visibility = View.GONE
        progressBar.visibility = View.VISIBLE
        progressText.visibility = View.VISIBLE
        progressBar.progress = 0
        progressText.text = "Preparing…"
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        Thread {
            var resultFile: File? = null
            var resultUri: Uri? = null
            var failure: String? = null
            try {
                current.applySettings(selectedVoice, rate, pitch)
                val chunks = TtsEngine.splitIntoChunks(
                    text, current.maxChunkLength())
                if (chunks.isEmpty()) {
                    failure = "The script is empty."
                } else {
                    val workDir = File(filesDir, "exports/work")
                    workDir.deleteRecursively()
                    workDir.mkdirs()
                    val parts = ArrayList<File>()
                    for ((index, chunk) in chunks.withIndex()) {
                        runOnUiThread {
                            progressBar.max = chunks.size
                            progressBar.progress = index
                            progressText.text =
                                "Generating part ${index + 1} of ${chunks.size}…"
                        }
                        val part = File(workDir, "part-$index.wav")
                        val ok = current.synthesizeChunk(chunk, part, 180)
                        if (!ok) {
                            failure = "The voice engine failed on part ${index + 1}."
                            break
                        }
                        parts.add(part)
                    }
                    if (failure == null) {
                        runOnUiThread { progressText.text = "Joining audio…" }
                        val stamp = SimpleDateFormat(
                            "yyyyMMdd-HHmmss", Locale.US).format(Date())
                        val merged = File(filesDir, "exports/VaaniStudio-$stamp.wav")
                        if (!WavMerger.merge(parts, merged)) {
                            failure = "The audio parts could not be joined."
                        } else {
                            runOnUiThread {
                                progressText.text = "Saving to Downloads…"
                            }
                            resultUri = saveToDownloads(merged)
                            resultFile = merged
                        }
                    }
                    workDir.deleteRecursively()
                }
            } catch (t: Throwable) {
                failure = "Unexpected problem: ${t.message}"
            }
            runOnUiThread {
                exporting = false
                exportButton.isEnabled = true
                exportButton.text = "Export full audio (WAV)"
                progressBar.visibility = View.GONE
                progressText.visibility = View.GONE
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                if (failure != null || resultFile == null) {
                    Toast.makeText(this,
                        failure ?: "Export failed.", Toast.LENGTH_LONG).show()
                } else {
                    lastExport = resultFile
                    lastExportUri = resultUri
                    val sizeMb = resultFile!!.length() / (1024.0 * 1024.0)
                    val where = if (resultUri != null) {
                        "Saved in Downloads › VaaniStudio."
                    } else {
                        "Saved inside the app (Downloads copy failed)."
                    }
                    resultText.text = String.format(Locale.US,
                        "%s\n%s (%.1f MB)", where, resultFile!!.name, sizeMb)
                    playButton.text = "Play"
                    resultCard.visibility = View.VISIBLE
                }
            }
        }.start()
    }

    private fun saveToDownloads(source: File): Uri? {
        return try {
            val values = ContentValues()
            values.put(MediaStore.Downloads.DISPLAY_NAME, source.name)
            values.put(MediaStore.Downloads.MIME_TYPE, "audio/wav")
            values.put(MediaStore.Downloads.RELATIVE_PATH,
                Environment.DIRECTORY_DOWNLOADS + "/VaaniStudio")
            values.put(MediaStore.Downloads.IS_PENDING, 1)
            val uri = contentResolver.insert(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
            contentResolver.openOutputStream(uri)?.use { output ->
                FileInputStream(source).use { input ->
                    input.copyTo(output, 64 * 1024)
                }
            } ?: return null
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            uri
        } catch (t: Throwable) {
            null
        }
    }

    private fun shareExport() {
        val uri = lastExportUri
        if (uri == null) {
            Toast.makeText(this,
                "Sharing needs the Downloads copy, which failed. " +
                "The file is still inside the app.", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "audio/wav"
        intent.putExtra(Intent.EXTRA_STREAM, uri)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(intent, "Share audio"))
    }

    private fun togglePlayback() {
        val file = lastExport ?: return
        val existing = player
        if (existing != null) {
            if (existing.isPlaying) {
                existing.pause()
                playButton.text = "Play"
            } else {
                existing.start()
                playButton.text = "Pause"
            }
            return
        }
        try {
            val fresh = MediaPlayer()
            fresh.setDataSource(file.absolutePath)
            fresh.prepare()
            fresh.setOnCompletionListener {
                playButton.text = "Play"
                stopPlayback()
            }
            fresh.start()
            player = fresh
            playButton.text = "Pause"
        } catch (t: Throwable) {
            Toast.makeText(this, "Playback failed.", Toast.LENGTH_SHORT).show()
            stopPlayback()
        }
    }

    private fun stopPlayback() {
        try {
            player?.stop()
            player?.release()
        } catch (ignored: Throwable) {
        }
        player = null
    }

    // ------------------------------------------------------------ Scripts

    private fun saveScriptDialog() {
        val text = scriptInput.text.toString().trim()
        if (text.isEmpty()) {
            Toast.makeText(this, "Write a script first.", Toast.LENGTH_SHORT).show()
            return
        }
        val input = EditText(this)
        input.hint = "Script name"
        input.setPadding(dp(16), dp(16), dp(16), dp(16))
        AlertDialog.Builder(this)
            .setTitle("Save script")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(this, "The name cannot be empty.",
                        Toast.LENGTH_SHORT).show()
                } else {
                    store.save(name, text)
                    Toast.makeText(this, "Saved \"$name\".",
                        Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openScriptsDialog() {
        val scripts = store.all()
        if (scripts.isEmpty()) {
            Toast.makeText(this, "No saved scripts yet.", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = scripts.map { script ->
            val date = SimpleDateFormat("dd MMM, HH:mm", Locale.US)
                .format(Date(script.updated))
            "${script.name}  •  $date"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("My scripts")
            .setItems(labels) { _, index ->
                scriptInput.setText(scripts[index].text)
                Toast.makeText(this, "Loaded \"${scripts[index].name}\".",
                    Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Delete…") { _, _ -> deleteScriptDialog(scripts) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun deleteScriptDialog(scripts: List<ScriptStore.Script>) {
        val labels = scripts.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Delete a script")
            .setItems(labels) { _, index ->
                store.delete(scripts[index].name)
                Toast.makeText(this, "Deleted \"${scripts[index].name}\".",
                    Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ----------------------------------------------------------- Cleanup

    override fun onDestroy() {
        stopPlayback()
        engine?.shutdown()
        engine = null
        super.onDestroy()
    }
}
