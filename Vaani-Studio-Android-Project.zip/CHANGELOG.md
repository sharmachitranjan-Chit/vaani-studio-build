# Changelog

## 1.0.1 — Launch repair

- Defers the custom audio module until recording, playback, or verification is requested.
- Defers Bare Kit and the offline voice engine until the user starts generation.
- Shows a readable startup diagnostic instead of a silent JavaScript exit.
- Disables release code and resource shrinking for this personal sideload build.
- Preserves native keep rules for the custom audio, Bare Kit, and buffer modules.
- Aligns React Native with the Expo 55 supported patch release.
- Uses a solid-color native splash to make clean cloud prebuilds deterministic.
- Raises Android `versionCode` to 2 so it can replace version 1.0.0.

## 1.0.0

- Initial offline Android voice-cloning build.
