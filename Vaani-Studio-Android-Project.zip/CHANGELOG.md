# Changelog

## 1.0.4 — Death certificate reader

- Reads Android's official record of why the previous process died
  (native crash, low-memory kill, signal, and so on) into the report.
- For native crashes, extracts the readable frames of the system tombstone,
  naming the exact faulting library.
- Raises Android `versionCode` to 5 so it can replace version 1.0.3.


## 1.0.3 — Boot stage tracing

- Records React engine markers (context creation, JS bundle start and end)
  into the boot log from the native side.
- Records a breadcrumb when the main activity is created.
- Adds a synchronous native mark function to the audio module so JavaScript
  can drop guaranteed breadcrumbs at bundle evaluation, app module load, and
  first screen readiness.
- Raises Android `versionCode` to 4 so it can replace version 1.0.2.


## 1.0.2 — Black box recorder

- Adds a native crash recorder that arms itself before React Native loads.
- Wraps native startup so a failure is recorded instead of silently closing.
- Adds a launch dispatcher that opens a readable crash report screen after a
  failed launch, with one-tap copy of the full stack trace and boot log.
- Logs boot-stage breadcrumbs (application start, native load, Expo modules,
  React UI ready) so even a C++ level crash reveals the stage it died at.
- Raises Android `versionCode` to 3 so it can replace version 1.0.1.


## 1.0.1 — Launch repair

- Defers the custom audio module until recording, playback, or verification is requested.
- Defers Bare Kit and the offline voice engine until the user starts generation.
- Shows a readable startup diagnostic instead of a silent JavaScript exit.
- Disables release code and resource shrinking for this personal sideload build.
- Preserves native keep rules for the custom audio, Bare Kit, and buffer modules.
- Aligns React Native with the Expo 55 supported patch release.
- Uses a solid-color native splash to make clean cloud prebuilds deterministic.
- Raises Android `versionCode` to 2 so it can replace version 1.0.0.

## 1.0.0

- Initial offline Android voice-cloning build.
