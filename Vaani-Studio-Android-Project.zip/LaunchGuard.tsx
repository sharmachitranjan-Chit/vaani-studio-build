import {
  Component,
  type ComponentType,
  type ErrorInfo,
  type ReactNode,
} from "react";
import {
  BackHandler,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

type BoundaryState = {
  error: Error | null;
};

class StartupBoundary extends Component<
  { children: ReactNode },
  BoundaryState
> {
  state: BoundaryState = { error: null };

  static getDerivedStateFromError(value: unknown): BoundaryState {
    return { error: normalizeError(value) };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("Vaani Studio startup error", error, info.componentStack);
  }

  render() {
    if (this.state.error) {
      return <StartupErrorScreen error={this.state.error} />;
    }
    return this.props.children;
  }
}

function DeferredApp() {
  // Keeping this require inside the guarded render is deliberate. If an
  // optional native feature is unavailable, Android can show the diagnostic
  // screen instead of closing before the first frame.
  const loaded = require("./App") as { default?: ComponentType };
  const App = loaded.default;
  if (!App) throw new Error("The app entry component could not be loaded");
  return <App />;
}

function StartupErrorScreen({ error }: { error: Error }) {
  const details = `${error.name}: ${error.message}`;
  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.mark}>
          <Text style={styles.markText}>!</Text>
        </View>
        <Text style={styles.eyebrow}>STARTUP DIAGNOSTIC • VS-101</Text>
        <Text style={styles.title}>Vaani Studio needs attention</Text>
        <Text style={styles.body}>
          The app caught a startup problem instead of closing. Take a screenshot
          of this screen and share it with the developer so the exact component
          can be repaired.
        </Text>
        <View style={styles.detailsBox}>
          <Text selectable style={styles.details}>
            {details}
          </Text>
        </View>
        <Pressable
          accessibilityRole="button"
          onPress={() => BackHandler.exitApp()}
          style={styles.button}
        >
          <Text style={styles.buttonText}>Close app</Text>
        </Pressable>
        <Text style={styles.footnote}>Vaani Studio 1.0.1 • Android arm64</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

function normalizeError(value: unknown) {
  if (value instanceof Error) return value;
  return new Error(typeof value === "string" ? value : JSON.stringify(value));
}

export default function LaunchGuard() {
  return (
    <StartupBoundary>
      <DeferredApp />
    </StartupBoundary>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#F4FBF7",
  },
  content: {
    flexGrow: 1,
    justifyContent: "center",
    padding: 28,
  },
  mark: {
    width: 54,
    height: 54,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#F6B73C",
    marginBottom: 20,
  },
  markText: {
    color: "#073B36",
    fontSize: 32,
    fontWeight: "900",
  },
  eyebrow: {
    color: "#C47C00",
    fontSize: 12,
    fontWeight: "800",
    letterSpacing: 1.2,
    marginBottom: 10,
  },
  title: {
    color: "#073B36",
    fontSize: 30,
    lineHeight: 36,
    fontWeight: "900",
    marginBottom: 14,
  },
  body: {
    color: "#365B55",
    fontSize: 16,
    lineHeight: 24,
  },
  detailsBox: {
    backgroundColor: "#E4F4EC",
    borderColor: "#B8DCCD",
    borderWidth: 1,
    borderRadius: 14,
    padding: 16,
    marginTop: 20,
  },
  details: {
    color: "#163E38",
    fontSize: 13,
    lineHeight: 19,
    fontFamily: "monospace",
  },
  button: {
    alignItems: "center",
    backgroundColor: "#073B36",
    borderRadius: 14,
    paddingVertical: 15,
    marginTop: 22,
  },
  buttonText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "800",
  },
  footnote: {
    color: "#718A85",
    fontSize: 12,
    textAlign: "center",
    marginTop: 16,
  },
});
