# Vaani Studio

Vaani Studio is a private Android text-to-speech app for Hindi, Hinglish, and English. It records or imports an authorized voice sample, downloads its model once, and then generates cloned-voice WAV audio entirely on the phone.

No account, subscription, analytics, API key, or cloud inference is used.

The current release is **1.0.1**. It includes a launch repair for the original 1.0.0 sideload build; see [CHANGELOG.md](CHANGELOG.md).

## What is included

- One-time, resumable model setup with SHA-256 integrity checks
- True 24 kHz, mono, 16-bit PCM microphone recording
- Local voice cloning from a short authorized sample
- Hindi, Hinglish, and English modes
- Optional Roman-Hindi pronunciation helper
- Long-script chunking, progress, and cancellation
- Local WAV playback, library, sharing, and deletion
- Android arm64 release workflow for GitHub Actions
- Deep-green, mint, and saffron MoneyClarityTech visual identity

## Phone requirements

- Android 12 or newer
- 64-bit ARM phone (the OnePlus Nord 4 is compatible)
- At least 1.25 GB free during first-time setup
- Wi-Fi for the initial model download
- 8 GB RAM recommended

The model download is about 830 MB. The app remains offline after it is verified. Voice generation is computationally heavy and is usually slower than real-time, especially on the first run.

## Build without a computer

Open [BUILD_ON_PHONE.md](BUILD_ON_PHONE.md) for the simplest ZIP-only GitHub method. GitHub builds a standalone, installable `Vaani-Studio.apk` for you.

If you upload the extracted project instead, the included `.github/workflows/build-android.yml` workflow builds it automatically.

## Development commands

```bash
npm ci
npm run check
npx expo prebuild --platform android --clean --no-install
cd android
./gradlew :app:assembleRelease -PreactNativeArchitectures=arm64-v8a
```

The APK is written to `android/app/build/outputs/apk/release/app-release.apk`. Expo's generated debug keystore signs this personal sideload build. Create and protect a production keystore before publishing through an app store.

## Privacy and responsible use

The model, reference voice, scripts, and generated audio stay in the app's private storage. The only runtime network activity is the user-started first model download from Hugging Face.

Clone only your own voice or a voice whose owner has clearly authorized you. Do not use generated audio to impersonate, deceive, defraud, or bypass consent. Vaani Studio labels saved items as AI-generated in its library.

## Main open-source components

- [QVAC `tts-onnx`](https://github.com/tetherto/qvac) — Apache-2.0
- [Chatterbox](https://github.com/resemble-ai/chatterbox) — MIT
- [Quantized multilingual ONNX model](https://huggingface.co/BricksDisplay/chatterbox-multilingual-ONNX-q4) — MIT model card
- [Bare Kit](https://github.com/holepunchto/react-native-bare-kit) — Apache-2.0
- [Expo](https://github.com/expo/expo) and [React Native](https://github.com/facebook/react-native) — MIT

See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) for attribution details.
