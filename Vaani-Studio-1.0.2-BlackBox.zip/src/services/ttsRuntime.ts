type TtsModule = typeof import("./ttsEngine");

let loadedModule: TtsModule | null = null;

export function getTtsEngine() {
  if (loadedModule) return loadedModule.ttsEngine;
  try {
    loadedModule = require("./ttsEngine") as TtsModule;
    if (!loadedModule?.ttsEngine)
      throw new Error("The engine module did not expose a TTS engine");
    return loadedModule.ttsEngine;
  } catch (value) {
    loadedModule = null;
    throw new Error(
      `The offline voice engine could not be opened. ${errorMessage(value)}`,
    );
  }
}

export function isGenerationCancelled(value: unknown) {
  return (
    typeof value === "object" &&
    value !== null &&
    "code" in value &&
    value.code === "CANCELLED"
  );
}

export function terminateTtsEngineIfLoaded() {
  loadedModule?.ttsEngine.terminate();
}

function errorMessage(value: unknown) {
  if (value instanceof Error) return value.message;
  return String(value);
}
