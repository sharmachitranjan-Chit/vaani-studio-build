import AsyncStorage from "@react-native-async-storage/async-storage";

import type { AudioItem, VoiceProfile } from "../types";

const KEYS = {
  voice: "@vaani/voice-v1",
  audio: "@vaani/audio-v1",
  consent: "@vaani/consent-v1",
};

export async function getVoiceProfile(): Promise<VoiceProfile | null> {
  const value = await AsyncStorage.getItem(KEYS.voice);
  if (!value) return null;
  try {
    return JSON.parse(value) as VoiceProfile;
  } catch {
    return null;
  }
}

export async function saveVoiceProfile(profile: VoiceProfile) {
  await AsyncStorage.setItem(KEYS.voice, JSON.stringify(profile));
}

export async function clearVoiceProfile() {
  await AsyncStorage.removeItem(KEYS.voice);
}

export async function getAudioLibrary(): Promise<AudioItem[]> {
  const value = await AsyncStorage.getItem(KEYS.audio);
  if (!value) return [];
  try {
    const items = JSON.parse(value) as AudioItem[];
    return items.sort((a, b) => b.createdAt - a.createdAt);
  } catch {
    return [];
  }
}

export async function addAudioItem(item: AudioItem) {
  const items = await getAudioLibrary();
  const next = [item, ...items.filter((existing) => existing.id !== item.id)];
  await AsyncStorage.setItem(KEYS.audio, JSON.stringify(next));
  return next;
}

export async function removeAudioItem(id: string) {
  const items = (await getAudioLibrary()).filter((item) => item.id !== id);
  await AsyncStorage.setItem(KEYS.audio, JSON.stringify(items));
  return items;
}

export async function hasAcceptedConsent() {
  return (await AsyncStorage.getItem(KEYS.consent)) === "yes";
}

export async function saveAcceptedConsent(accepted = true) {
  if (accepted) await AsyncStorage.setItem(KEYS.consent, "yes");
  else await AsyncStorage.removeItem(KEYS.consent);
}
