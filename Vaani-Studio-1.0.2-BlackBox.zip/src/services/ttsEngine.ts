import b4a from "b4a";
import { Worklet } from "react-native-bare-kit";

import bundle from "../generated/tts.bundle.js";
import type { EngineMessage } from "../types";

type PendingRequest = {
  successTypes: Set<string>;
  resolve: (message: EngineMessage) => void;
  reject: (error: Error) => void;
  onProgress?: (message: EngineMessage) => void;
  timer: ReturnType<typeof setTimeout>;
};

class EngineError extends Error {
  code: string;

  constructor(message: string, code = "ENGINE_ERROR") {
    super(message);
    this.name = "EngineError";
    this.code = code;
  }
}

class VaaniTtsEngine {
  private worklet: Worklet | null = null;
  private inputBuffer = "";
  private pending = new Map<string, PendingRequest>();
  private bootPromise: Promise<void> | null = null;
  private bootResolve: (() => void) | null = null;
  private bootReject: ((error: Error) => void) | null = null;
  private bootTimer: ReturnType<typeof setTimeout> | null = null;
  private serial = 0;

  async start() {
    if (this.worklet) return this.bootPromise;
    this.bootPromise = new Promise<void>((resolve, reject) => {
      this.bootResolve = resolve;
      this.bootReject = reject;
      this.bootTimer = setTimeout(() => {
        reject(
          new EngineError(
            "The offline engine took too long to start",
            "START_TIMEOUT",
          ),
        );
      }, 20_000);
    });

    try {
      const worklet = new Worklet(`vaani-${Date.now()}`);
      this.worklet = worklet;
      worklet.IPC.on("data", (data: unknown) =>
        this.receive(data as Uint8Array),
      );
      worklet.IPC.on("error", (error: Error) => this.failAll(error));
      worklet.start("/vaani-tts.bundle", bundle);
    } catch (error) {
      const normalized = toError(error);
      this.bootReject?.(normalized);
      this.bootResolve = null;
      this.bootReject = null;
      throw normalized;
    }
    return this.bootPromise;
  }

  async initialize(options: {
    modelDir: string;
    voicePath: string;
    language: string;
    onStatus?: (message: EngineMessage) => void;
  }) {
    await this.start();
    return this.request(
      {
        type: "init",
        modelDir: options.modelDir,
        voicePath: options.voicePath,
        language: options.language,
        numThreads: 4,
      },
      ["ready"],
      120_000,
      options.onStatus,
    );
  }

  async generate(options: {
    text: string;
    outputPath: string;
    language: string;
    locale: string;
    onProgress?: (message: EngineMessage) => void;
  }) {
    return this.request(
      {
        type: "generate",
        text: options.text,
        outputPath: options.outputPath,
        language: options.language,
        locale: options.locale,
      },
      ["complete"],
      2 * 60 * 60_000,
      options.onProgress,
    );
  }

  async cancel() {
    if (!this.worklet) return;
    const id = this.nextId();
    this.send({ type: "cancel", id });
  }

  terminate() {
    if (!this.worklet) return;
    try {
      this.send({ type: "shutdown", id: this.nextId() });
    } catch {}
    this.worklet.terminate();
    this.worklet = null;
    this.bootPromise = null;
    this.failAll(
      new EngineError("The offline engine was closed", "TERMINATED"),
    );
  }

  private async request(
    message: Record<string, unknown>,
    successTypes: string[],
    timeoutMs: number,
    onProgress?: (message: EngineMessage) => void,
  ) {
    await this.start();
    const id = this.nextId();
    return new Promise<EngineMessage>((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new EngineError("The offline engine timed out", "TIMEOUT"));
      }, timeoutMs);
      this.pending.set(id, {
        successTypes: new Set(successTypes),
        resolve,
        reject,
        onProgress,
        timer,
      });
      try {
        this.send({ ...message, id });
      } catch (error) {
        clearTimeout(timer);
        this.pending.delete(id);
        reject(toError(error));
      }
    });
  }

  private nextId() {
    this.serial += 1;
    return `${Date.now()}-${this.serial}`;
  }

  private send(message: Record<string, unknown>) {
    if (!this.worklet)
      throw new EngineError("The offline engine is not running", "NOT_RUNNING");
    this.worklet.IPC.write(b4a.from(`${JSON.stringify(message)}\n`));
  }

  private receive(data: Uint8Array) {
    this.inputBuffer += b4a.toString(data);
    while (true) {
      const newline = this.inputBuffer.indexOf("\n");
      if (newline < 0) break;
      const line = this.inputBuffer.slice(0, newline).trim();
      this.inputBuffer = this.inputBuffer.slice(newline + 1);
      if (!line) continue;
      try {
        this.handleMessage(JSON.parse(line) as EngineMessage);
      } catch {
        // A malformed diagnostic line should not interrupt a generation job.
      }
    }
  }

  private handleMessage(message: EngineMessage) {
    if (message.type === "booted") {
      if (this.bootTimer) clearTimeout(this.bootTimer);
      this.bootResolve?.();
      this.bootResolve = null;
      this.bootReject = null;
      return;
    }

    const id = typeof message.id === "string" ? message.id : null;
    if (!id) return;
    const request = this.pending.get(id);
    if (!request) return;

    if (message.type === "error") {
      clearTimeout(request.timer);
      this.pending.delete(id);
      request.reject(
        new EngineError(
          message.message || "Audio generation failed",
          message.code,
        ),
      );
      return;
    }
    if (message.type === "cancelled") {
      clearTimeout(request.timer);
      this.pending.delete(id);
      request.reject(new EngineError("Generation cancelled", "CANCELLED"));
      return;
    }
    if (request.successTypes.has(message.type)) {
      clearTimeout(request.timer);
      this.pending.delete(id);
      request.resolve(message);
      return;
    }
    request.onProgress?.(message);
  }

  private failAll(error: Error) {
    if (this.bootTimer) clearTimeout(this.bootTimer);
    this.bootReject?.(error);
    this.bootResolve = null;
    this.bootReject = null;
    for (const request of this.pending.values()) {
      clearTimeout(request.timer);
      request.reject(error);
    }
    this.pending.clear();
  }
}

function toError(value: unknown) {
  return value instanceof Error ? value : new Error(String(value));
}

export const ttsEngine = new VaaniTtsEngine();
export { EngineError };
