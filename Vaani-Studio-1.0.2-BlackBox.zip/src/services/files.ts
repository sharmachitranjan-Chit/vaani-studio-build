import * as FileSystem from "expo-file-system/legacy";

const root = `${FileSystem.documentDirectory}vaani-studio/`;

export const paths = {
  root,
  modelUri: `${root}model/chatterbox-q4/`,
  voicesUri: `${root}voices/`,
  outputsUri: `${root}outputs/`,
};

export async function ensureAppFolders() {
  for (const uri of [
    paths.root,
    paths.modelUri,
    paths.voicesUri,
    paths.outputsUri,
  ]) {
    await FileSystem.makeDirectoryAsync(uri, { intermediates: true });
  }
}

export function uriToPath(uri: string) {
  if (!uri.startsWith("file://")) return uri;
  return decodeURIComponent(uri.replace(/^file:\/\//, ""));
}

export function fileSafeTimestamp(date = new Date()) {
  return date
    .toISOString()
    .replace(/[:.]/g, "-")
    .replace("T", "_")
    .replace("Z", "");
}

export function formatBytes(bytes: number) {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 MB";
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  if (bytes < 1024 * 1024 * 1024)
    return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  return `${(bytes / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

export function formatDuration(milliseconds: number) {
  const totalSeconds = Math.max(0, Math.round(milliseconds / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = String(totalSeconds % 60).padStart(2, "0");
  return `${minutes}:${seconds}`;
}
