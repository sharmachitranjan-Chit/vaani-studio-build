import type {
  PlaybackStatus,
  RecordingResult,
  RecordingStatus,
  WavInfo,
} from "../../modules/vaani-audio/src/VaaniAudio.types";

type NativeAudioModule = {
  startRecording(fileUri: string): Promise<RecordingStatus>;
  stopRecording(): Promise<RecordingResult>;
  getRecordingStatus(): Promise<RecordingStatus>;
  inspectWav(fileUri: string): Promise<WavInfo>;
  sha256File(fileUri: string): Promise<string>;
  startPlayback(fileUri: string): Promise<PlaybackStatus>;
  pausePlayback(): Promise<PlaybackStatus>;
  resumePlayback(): Promise<PlaybackStatus>;
  stopPlayback(): Promise<PlaybackStatus>;
  getPlaybackStatus(): Promise<PlaybackStatus>;
};

let cachedModule: NativeAudioModule | null = null;

export function getNativeAudio(): NativeAudioModule {
  if (cachedModule) return cachedModule;
  try {
    const loaded = require("../../modules/vaani-audio") as {
      default?: NativeAudioModule;
    };
    if (!loaded.default)
      throw new Error("VaaniAudio did not return a native module");
    cachedModule = loaded.default;
    return cachedModule;
  } catch (value) {
    throw new Error(
      `The on-device audio component is unavailable. ${errorMessage(value)}`,
    );
  }
}

function errorMessage(value: unknown) {
  if (value instanceof Error) return value.message;
  return String(value);
}
