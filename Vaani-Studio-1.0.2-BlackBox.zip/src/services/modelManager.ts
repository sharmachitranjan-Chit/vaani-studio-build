import AsyncStorage from "@react-native-async-storage/async-storage";
import * as FileSystem from "expo-file-system/legacy";

import { ensureAppFolders, formatBytes, paths, uriToPath } from "./files";
import { getNativeAudio } from "./nativeAudio";

type ModelFile = {
  name: string;
  estimatedBytes: number;
  sha256?: string;
  relativeUrl: string;
};

export type ModelProgress = {
  phase: "checking" | "downloading" | "verifying" | "complete" | "paused";
  fileName: string;
  fileIndex: number;
  fileCount: number;
  fileProgress: number;
  overallProgress: number;
  downloadedBytes: number;
  totalBytes: number;
  message: string;
};

type VerifiedFiles = Record<string, { sha256: string; bytes: number }>;

const STORAGE_KEY = "@vaani/model-files-v2";
const PAUSE_KEY = "@vaani/model-pause-v2";
const REPOSITORY = "BricksDisplay/chatterbox-multilingual-ONNX-q4";
const MODEL_REVISION = "171d2d625bf424fd39847c10d4ebdd6612ea81f6";
const BASE_URL = `https://huggingface.co/${REPOSITORY}/resolve/${MODEL_REVISION}/`;

export const MODEL_FILES: ModelFile[] = [
  {
    name: "tokenizer.json",
    estimatedBytes: 74_000,
    relativeUrl: "tokenizer.json",
  },
  {
    name: "embed_tokens.onnx",
    estimatedBytes: 68_400_000,
    sha256: "b213e0cf547c2de64146de96781ae8742a130fe54e1f577bc7e5ec6cfb39be06",
    relativeUrl: "onnx/embed_tokens.onnx",
  },
  {
    name: "speech_encoder.onnx",
    estimatedBytes: 180_000_000,
    sha256: "7d32d3d75572c76cb7cd9e0489932fc758e242780c85ecd16bf6a3c2f0744838",
    relativeUrl: "onnx/speech_encoder.onnx",
  },
  {
    name: "conditional_decoder.onnx",
    estimatedBytes: 226_000_000,
    sha256: "0a7fae0f1c2a94f02e4a30e15242b9119be7b4b0428306e0dd9038e05328b85e",
    relativeUrl: "onnx/conditional_decoder.onnx",
  },
  {
    name: "language_model.onnx",
    estimatedBytes: 354_000_000,
    sha256: "d4f8bde071758d8e869a5b78e16d78d17c55ec594d445781f29e1ebcf39f1865",
    relativeUrl: "onnx/language_model.onnx",
  },
];

const estimatedTotal = MODEL_FILES.reduce(
  (sum, file) => sum + file.estimatedBytes,
  0,
);
let activeDownload: FileSystem.DownloadResumable | null = null;
let pauseRequested = false;

async function readVerifiedFiles(): Promise<VerifiedFiles> {
  try {
    return JSON.parse(
      (await AsyncStorage.getItem(STORAGE_KEY)) || "{}",
    ) as VerifiedFiles;
  } catch {
    return {};
  }
}

async function saveVerifiedFiles(value: VerifiedFiles) {
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(value));
}

export async function isModelInstalled() {
  const verified = await readVerifiedFiles();
  for (const file of MODEL_FILES) {
    const info = await FileSystem.getInfoAsync(`${paths.modelUri}${file.name}`);
    const record = verified[file.name];
    if (
      !info.exists ||
      info.isDirectory ||
      !record ||
      !("size" in info) ||
      info.size !== record.bytes
    ) {
      return false;
    }
    if (file.sha256 && record.sha256 !== file.sha256) return false;
  }
  return true;
}

export async function modelDiskUsage() {
  let bytes = 0;
  for (const file of MODEL_FILES) {
    const info = await FileSystem.getInfoAsync(`${paths.modelUri}${file.name}`);
    if (info.exists && !info.isDirectory && "size" in info) bytes += info.size;
  }
  return bytes;
}

export async function downloadModel(
  onProgress: (progress: ModelProgress) => void,
) {
  await ensureAppFolders();
  pauseRequested = false;
  const verified = await readVerifiedFiles();
  const verifiedEstimated = MODEL_FILES.reduce(
    (sum, file) => sum + (verified[file.name] ? file.estimatedBytes : 0),
    0,
  );
  const remainingEstimated = estimatedTotal - verifiedEstimated;
  const requiredFreeBytes = Math.min(
    1_250_000_000,
    Math.max(350_000_000, remainingEstimated + 300_000_000),
  );
  const freeBytes = await FileSystem.getFreeDiskStorageAsync();
  if (freeBytes < requiredFreeBytes) {
    throw new Error(
      `Vaani Studio needs about ${formatBytes(requiredFreeBytes)} free to continue setup. Your phone currently reports ${formatBytes(freeBytes)} free.`,
    );
  }

  let completedEstimated = 0;

  for (let index = 0; index < MODEL_FILES.length; index++) {
    const file = MODEL_FILES[index]!;
    const destination = `${paths.modelUri}${file.name}`;
    const existing = await FileSystem.getInfoAsync(destination);
    const record = verified[file.name];
    if (
      existing.exists &&
      !existing.isDirectory &&
      record &&
      "size" in existing &&
      existing.size === record.bytes &&
      (!file.sha256 || record.sha256 === file.sha256)
    ) {
      completedEstimated += file.estimatedBytes;
      continue;
    }

    const pausedJson = await AsyncStorage.getItem(PAUSE_KEY);
    let paused: FileSystem.DownloadPauseState | null = null;
    try {
      const candidate = pausedJson
        ? (JSON.parse(pausedJson) as FileSystem.DownloadPauseState)
        : null;
      if (candidate?.fileUri === destination) paused = candidate;
    } catch {}

    if (paused && !existing.exists) {
      paused = null;
      await AsyncStorage.removeItem(PAUSE_KEY);
    }

    if (existing.exists && !paused)
      await FileSystem.deleteAsync(destination, { idempotent: true });
    delete verified[file.name];
    await saveVerifiedFiles(verified);

    const url = `${BASE_URL}${file.relativeUrl}?download=true`;
    const callback = (event: FileSystem.DownloadProgressData) => {
      const total = event.totalBytesExpectedToWrite || file.estimatedBytes;
      const written = event.totalBytesWritten;
      const ratio = Math.max(0, Math.min(1, written / Math.max(1, total)));
      onProgress({
        phase: "downloading",
        fileName: file.name,
        fileIndex: index + 1,
        fileCount: MODEL_FILES.length,
        fileProgress: ratio,
        overallProgress: Math.min(
          0.98,
          (completedEstimated + ratio * file.estimatedBytes) / estimatedTotal,
        ),
        downloadedBytes: completedEstimated + written,
        totalBytes: estimatedTotal,
        message: `Downloading ${file.name} (${index + 1} of ${MODEL_FILES.length})`,
      });
    };

    activeDownload = FileSystem.createDownloadResumable(
      url,
      destination,
      { headers: { Accept: "application/octet-stream" } },
      callback,
      paused?.resumeData,
    );
    let result: FileSystem.FileSystemDownloadResult | undefined;
    try {
      result = paused
        ? await activeDownload.resumeAsync()
        : await activeDownload.downloadAsync();
    } finally {
      activeDownload = null;
    }

    if (pauseRequested || !result) {
      onProgress({
        phase: "paused",
        fileName: file.name,
        fileIndex: index + 1,
        fileCount: MODEL_FILES.length,
        fileProgress: 0,
        overallProgress: completedEstimated / estimatedTotal,
        downloadedBytes: completedEstimated,
        totalBytes: estimatedTotal,
        message: "Download paused",
      });
      return false;
    }
    await AsyncStorage.removeItem(PAUSE_KEY);

    onProgress({
      phase: "verifying",
      fileName: file.name,
      fileIndex: index + 1,
      fileCount: MODEL_FILES.length,
      fileProgress: 1,
      overallProgress:
        (completedEstimated + file.estimatedBytes) / estimatedTotal,
      downloadedBytes: completedEstimated + file.estimatedBytes,
      totalBytes: estimatedTotal,
      message: `Checking ${file.name}…`,
    });

    const info = await FileSystem.getInfoAsync(destination);
    if (
      !info.exists ||
      info.isDirectory ||
      !("size" in info) ||
      info.size < 1_000
    ) {
      throw new Error(`${file.name} did not download correctly`);
    }
    const hash = file.sha256
      ? await getNativeAudio().sha256File(destination)
      : "";
    if (file.sha256 && hash !== file.sha256) {
      await FileSystem.deleteAsync(destination, { idempotent: true });
      throw new Error(
        `${file.name} failed its safety check. Please retry the download.`,
      );
    }
    if (file.name === "tokenizer.json") {
      try {
        JSON.parse(await FileSystem.readAsStringAsync(destination));
      } catch {
        await FileSystem.deleteAsync(destination, { idempotent: true });
        throw new Error(
          "tokenizer.json is not valid JSON. Please retry the download.",
        );
      }
    }
    verified[file.name] = { sha256: hash, bytes: info.size };
    await saveVerifiedFiles(verified);
    completedEstimated += file.estimatedBytes;
  }

  onProgress({
    phase: "complete",
    fileName: "",
    fileIndex: MODEL_FILES.length,
    fileCount: MODEL_FILES.length,
    fileProgress: 1,
    overallProgress: 1,
    downloadedBytes: estimatedTotal,
    totalBytes: estimatedTotal,
    message: "Offline model is ready",
  });
  return true;
}

export async function pauseModelDownload() {
  if (!activeDownload) return;
  pauseRequested = true;
  const state = await activeDownload.pauseAsync();
  await AsyncStorage.setItem(PAUSE_KEY, JSON.stringify(state));
}

export async function removeModel() {
  await pauseModelDownload();
  await FileSystem.deleteAsync(paths.modelUri, { idempotent: true });
  await AsyncStorage.multiRemove([STORAGE_KEY, PAUSE_KEY]);
  await FileSystem.makeDirectoryAsync(paths.modelUri, { intermediates: true });
}

export function getModelPath() {
  return uriToPath(paths.modelUri);
}
