declare module "b4a" {
  type Binary = Uint8Array;

  const b4a: {
    from(
      value: string | ArrayBuffer | ArrayBufferView | number[],
      encoding?: string,
    ): Binary;
    toString(value: Binary, encoding?: string): string;
    alloc(size: number, fill?: number): Binary;
  };

  export default b4a;
}
