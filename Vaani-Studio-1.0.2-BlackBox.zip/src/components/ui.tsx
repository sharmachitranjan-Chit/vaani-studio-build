import type { ReactNode } from "react";
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  View,
  type StyleProp,
  type ViewStyle,
} from "react-native";

import { colors, radii } from "../theme";

export function Card({
  children,
  style,
}: {
  children: ReactNode;
  style?: StyleProp<ViewStyle>;
}) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function Button({
  title,
  onPress,
  disabled = false,
  busy = false,
  variant = "primary",
  compact = false,
  accessibilityLabel,
}: {
  title: string;
  onPress: () => void;
  disabled?: boolean;
  busy?: boolean;
  variant?: "primary" | "secondary" | "ghost" | "danger";
  compact?: boolean;
  accessibilityLabel?: string;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel || title}
      disabled={disabled || busy}
      onPress={onPress}
      style={({ pressed }) => [
        styles.button,
        compact && styles.buttonCompact,
        variant === "secondary" && styles.buttonSecondary,
        variant === "ghost" && styles.buttonGhost,
        variant === "danger" && styles.buttonDanger,
        (disabled || busy) && styles.buttonDisabled,
        pressed && !disabled && !busy && styles.buttonPressed,
      ]}
    >
      {busy ? (
        <ActivityIndicator
          color={variant === "primary" ? colors.white : colors.green}
          size="small"
        />
      ) : null}
      <Text
        style={[
          styles.buttonText,
          variant !== "primary" &&
            variant !== "danger" &&
            styles.buttonTextSecondary,
        ]}
      >
        {title}
      </Text>
    </Pressable>
  );
}

export function ProgressBar({
  value,
  color = colors.saffron,
}: {
  value: number;
  color?: string;
}) {
  const safe = Math.max(0, Math.min(1, value || 0));
  return (
    <View
      accessibilityRole="progressbar"
      accessibilityValue={{ min: 0, max: 100, now: Math.round(safe * 100) }}
      style={styles.progressTrack}
    >
      <View
        style={[
          styles.progressFill,
          { width: `${safe * 100}%`, backgroundColor: color },
        ]}
      />
    </View>
  );
}

export function Pill({
  children,
  tone = "green",
}: {
  children: ReactNode;
  tone?: "green" | "saffron" | "gray";
}) {
  return (
    <View
      style={[
        styles.pill,
        tone === "saffron" && styles.pillSaffron,
        tone === "gray" && styles.pillGray,
      ]}
    >
      <Text
        style={[
          styles.pillText,
          tone === "saffron" && styles.pillTextSaffron,
          tone === "gray" && styles.pillTextGray,
        ]}
      >
        {children}
      </Text>
    </View>
  );
}

export function SectionTitle({
  title,
  subtitle,
}: {
  title: string;
  subtitle?: string;
}) {
  return (
    <View style={styles.sectionHeading}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {subtitle ? <Text style={styles.sectionSubtitle}>{subtitle}</Text> : null}
    </View>
  );
}

export function CheckRow({
  checked,
  text,
  onPress,
}: {
  checked: boolean;
  text: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      accessibilityRole="checkbox"
      accessibilityState={{ checked }}
      onPress={onPress}
      style={styles.checkRow}
    >
      <View style={[styles.checkbox, checked && styles.checkboxChecked]}>
        {checked ? <Text style={styles.checkmark}>✓</Text> : null}
      </View>
      <Text style={styles.checkText}>{text}</Text>
    </Pressable>
  );
}

export function InlineNotice({
  children,
  tone = "mint",
}: {
  children: ReactNode;
  tone?: "mint" | "saffron" | "danger";
}) {
  return (
    <View
      style={[
        styles.notice,
        tone === "saffron" && styles.noticeSaffron,
        tone === "danger" && styles.noticeDanger,
      ]}
    >
      <Text
        style={[
          styles.noticeText,
          tone === "danger" && styles.noticeDangerText,
        ]}
      >
        {children}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.white,
    borderColor: colors.border,
    borderRadius: radii.large,
    borderWidth: 1,
    padding: 18,
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.06,
    shadowRadius: 14,
    elevation: 2,
  },
  button: {
    minHeight: 52,
    paddingHorizontal: 20,
    borderRadius: radii.medium,
    backgroundColor: colors.green,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 9,
  },
  buttonCompact: {
    minHeight: 42,
    paddingHorizontal: 15,
    borderRadius: radii.small,
  },
  buttonSecondary: {
    backgroundColor: colors.mintSoft,
    borderColor: colors.green,
    borderWidth: 1,
  },
  buttonGhost: {
    backgroundColor: "transparent",
    borderColor: colors.border,
    borderWidth: 1,
  },
  buttonDanger: {
    backgroundColor: colors.danger,
  },
  buttonDisabled: {
    opacity: 0.45,
  },
  buttonPressed: {
    transform: [{ scale: 0.985 }],
    opacity: 0.9,
  },
  buttonText: {
    color: colors.white,
    fontSize: 15,
    fontWeight: "800",
    letterSpacing: 0.2,
  },
  buttonTextSecondary: {
    color: colors.green,
  },
  progressTrack: {
    height: 9,
    backgroundColor: "#E7EEE9",
    borderRadius: radii.pill,
    overflow: "hidden",
  },
  progressFill: {
    height: "100%",
    borderRadius: radii.pill,
  },
  pill: {
    alignSelf: "flex-start",
    paddingHorizontal: 10,
    paddingVertical: 5,
    backgroundColor: colors.mintSoft,
    borderRadius: radii.pill,
  },
  pillSaffron: {
    backgroundColor: colors.saffronSoft,
  },
  pillGray: {
    backgroundColor: "#EDF2EF",
  },
  pillText: {
    color: colors.green,
    fontSize: 11,
    fontWeight: "800",
    letterSpacing: 0.4,
    textTransform: "uppercase",
  },
  pillTextSaffron: {
    color: "#9A5D00",
  },
  pillTextGray: {
    color: colors.muted,
  },
  sectionHeading: {
    gap: 4,
  },
  sectionTitle: {
    color: colors.ink,
    fontSize: 24,
    fontWeight: "900",
    letterSpacing: -0.6,
  },
  sectionSubtitle: {
    color: colors.muted,
    fontSize: 14,
    lineHeight: 20,
  },
  checkRow: {
    flexDirection: "row",
    gap: 12,
    alignItems: "flex-start",
    paddingVertical: 4,
  },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 7,
    borderWidth: 2,
    borderColor: colors.green,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 1,
  },
  checkboxChecked: {
    backgroundColor: colors.green,
  },
  checkmark: {
    color: colors.white,
    fontWeight: "900",
  },
  checkText: {
    flex: 1,
    color: colors.ink,
    fontSize: 14,
    lineHeight: 21,
    fontWeight: "600",
  },
  notice: {
    padding: 13,
    borderRadius: radii.small,
    backgroundColor: colors.mintSoft,
    borderLeftWidth: 4,
    borderLeftColor: colors.success,
  },
  noticeSaffron: {
    backgroundColor: colors.saffronSoft,
    borderLeftColor: colors.saffron,
  },
  noticeDanger: {
    backgroundColor: colors.dangerSoft,
    borderLeftColor: colors.danger,
  },
  noticeText: {
    color: colors.ink,
    fontSize: 13,
    lineHeight: 19,
    fontWeight: "600",
  },
  noticeDangerText: {
    color: colors.danger,
  },
});
