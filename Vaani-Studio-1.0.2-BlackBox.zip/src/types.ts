export type LanguageMode = "hinglish" | "hindi" | "english";

export type VoiceProfile = {
  name: string;
  fileUri: string;
  durationMs: number;
  sampleRate: number;
  createdAt: number;
  source: "recorded" | "imported";
  consented: true;
};

export type AudioItem = {
  id: string;
  title: string;
  fileUri: string;
  createdAt: number;
  durationMs: number;
  bytes: number;
  language: LanguageMode;
  characters: number;
  aiGenerated: true;
};

export type EngineMessage = {
  type: string;
  id?: string | null;
  code?: string;
  message?: string;
  stage?: string;
  progress?: number;
  chunks?: number;
  sentence?: string;
  outputPath?: string;
  durationMs?: number;
  bytes?: number;
  elapsedMs?: number;
  sampleSeconds?: number;
  [key: string]: unknown;
};
