export const colors = {
  ink: "#142622",
  muted: "#60736D",
  green: "#073B36",
  greenLight: "#0C5F54",
  mint: "#A7F3D0",
  mintSoft: "#E6F8EF",
  saffron: "#F59E0B",
  saffronSoft: "#FFF5DB",
  cream: "#F6FBF8",
  white: "#FFFFFF",
  border: "#D7E5DF",
  danger: "#B42318",
  dangerSoft: "#FEECEB",
  success: "#167A5A",
  shadow: "#052E2B",
};

export const radii = {
  small: 10,
  medium: 16,
  large: 24,
  pill: 999,
};
