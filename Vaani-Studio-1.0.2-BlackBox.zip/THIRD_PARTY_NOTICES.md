# Third-party notices

Vaani Studio is assembled from open-source software. The dependencies installed by `npm ci` retain their own license files inside their packages.

## QVAC TTS and ONNX runtime bindings

Copyright 2026 Tether Data, S.A. de C.V.

`@qvac/tts-onnx`, `@qvac/onnx`, and related QVAC packages are licensed under the Apache License 2.0. Their source and full notices are available in the [QVAC repository](https://github.com/tetherto/qvac) and their installed npm package directories.

## Bare Kit and Bare ecosystem

Copyright Holepunch contributors.

`react-native-bare-kit`, Bare runtime components, and supporting Holepunch packages are licensed primarily under the Apache License 2.0. See each installed package for its exact license.

## Chatterbox and model weights

Chatterbox source and weights are released under the MIT License by Resemble AI. Vaani Studio downloads the community ONNX Q4 conversion published at `BricksDisplay/chatterbox-multilingual-ONNX-q4`; consult its model card before redistribution.

## Expo, React, and React Native

Expo, React, and React Native are distributed under the MIT License. Additional transitive packages remain governed by the licenses shipped with them.

This notice is informational and does not replace any dependency's full license text.
