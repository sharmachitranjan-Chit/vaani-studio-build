import { useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  PermissionsAndroid,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from "react-native";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import { activateKeepAwakeAsync, deactivateKeepAwake } from "expo-keep-awake";
import * as Sharing from "expo-sharing";
import { StatusBar } from "expo-status-bar";
import * as SystemUI from "expo-system-ui";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";

import type { PlaybackStatus, RecordingStatus } from "./modules/vaani-audio";
import {
  Button,
  Card,
  CheckRow,
  InlineNotice,
  Pill,
  ProgressBar,
  SectionTitle,
} from "./src/components/ui";
import { colors, radii } from "./src/theme";
import type {
  AudioItem,
  EngineMessage,
  LanguageMode,
  VoiceProfile,
} from "./src/types";
import {
  ensureAppFolders,
  fileSafeTimestamp,
  formatBytes,
  formatDuration,
  paths,
  uriToPath,
} from "./src/services/files";
import { engineLanguage, prepareSpeechText } from "./src/services/hinglish";
import { getNativeAudio } from "./src/services/nativeAudio";
import {
  downloadModel,
  getModelPath,
  isModelInstalled,
  modelDiskUsage,
  pauseModelDownload,
  removeModel,
  type ModelProgress,
} from "./src/services/modelManager";
import {
  addAudioItem,
  clearVoiceProfile,
  getAudioLibrary,
  getVoiceProfile,
  hasAcceptedConsent,
  removeAudioItem,
  saveAcceptedConsent,
  saveVoiceProfile,
} from "./src/services/storage";
import {
  getTtsEngine,
  isGenerationCancelled,
  terminateTtsEngineIfLoaded,
} from "./src/services/ttsRuntime";

type Tab = "create" | "voice" | "library";

const sampleLine = "आज मैं अपने पैसों को समझदारी से संभालना सीख रहा हूँ।";
const defaultDraft =
  "Aaj hum samjhenge ki emergency fund kyun zaroori hai. Har mahine apni income ka ek chhota hissa alag rakhein, taaki mushkil samay mein loan na lena pade.";

export default function App() {
  const [hydrated, setHydrated] = useState(false);
  const [modelReady, setModelReady] = useState(false);
  const [modelBytes, setModelBytes] = useState(0);
  const [voice, setVoice] = useState<VoiceProfile | null>(null);
  const [consent, setConsent] = useState(false);
  const [library, setLibrary] = useState<AudioItem[]>([]);
  const [tab, setTab] = useState<Tab>("create");
  const [setupDismissed, setSetupDismissed] = useState(false);

  const [downloading, setDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] =
    useState<ModelProgress | null>(null);
  const [recording, setRecording] = useState<RecordingStatus | null>(null);
  const [recordBusy, setRecordBusy] = useState(false);
  const recordingTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const stoppingRecording = useRef(false);

  const [mode, setMode] = useState<LanguageMode>("hinglish");
  const [improveHinglish, setImproveHinglish] = useState(true);
  const [draft, setDraft] = useState(defaultDraft);
  const [generating, setGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [generationStatus, setGenerationStatus] = useState("");
  const [lastGenerated, setLastGenerated] = useState<AudioItem | null>(null);
  const initializedVoice = useRef("");

  const [playingUri, setPlayingUri] = useState<string | null>(null);
  const [playback, setPlayback] = useState<PlaybackStatus | null>(null);

  const speechText = useMemo(
    () => prepareSpeechText(draft, mode, improveHinglish),
    [draft, mode, improveHinglish],
  );
  const setupComplete = modelReady && !!voice && consent;
  const showSetup = !setupComplete || !setupDismissed;

  useEffect(() => {
    SystemUI.setBackgroundColorAsync(colors.cream).catch(() => {});
    let mounted = true;
    (async () => {
      try {
        await ensureAppFolders();
        const [installed, savedVoice, savedLibrary, accepted, usage] =
          await Promise.all([
            isModelInstalled(),
            getVoiceProfile(),
            getAudioLibrary(),
            hasAcceptedConsent(),
            modelDiskUsage(),
          ]);
        let validVoice = savedVoice;
        if (savedVoice) {
          const info = await FileSystem.getInfoAsync(savedVoice.fileUri);
          if (!info.exists) {
            await clearVoiceProfile();
            validVoice = null;
          }
        }
        if (mounted) {
          setModelReady(installed);
          setModelBytes(usage);
          setVoice(validVoice);
          setLibrary(savedLibrary);
          setConsent(accepted);
          setSetupDismissed(installed && !!validVoice && accepted);
        }
      } catch (error) {
        if (mounted) showError(error);
      } finally {
        if (mounted) setHydrated(true);
      }
    })();
    return () => {
      mounted = false;
      if (recordingTimer.current) clearInterval(recordingTimer.current);
    };
  }, []);

  useEffect(() => {
    if (!playingUri) return;
    const timer = setInterval(async () => {
      try {
        const status = await getNativeAudio().getPlaybackStatus();
        setPlayback(status);
        if (!status.isLoaded) setPlayingUri(null);
      } catch {}
    }, 350);
    return () => clearInterval(timer);
  }, [playingUri]);

  const handleConsent = async () => {
    const next = !consent;
    setConsent(next);
    await saveAcceptedConsent(next);
  };

  const handleDownload = async () => {
    setDownloading(true);
    setDownloadProgress(null);
    try {
      await activateKeepAwakeAsync("vaani-model-download");
      const finished = await downloadModel(setDownloadProgress);
      if (finished) {
        setModelReady(true);
        setModelBytes(await modelDiskUsage());
      }
    } catch (error) {
      showError(error, "Model setup stopped");
    } finally {
      setDownloading(false);
      await deactivateKeepAwake("vaani-model-download").catch(() => {});
    }
  };

  const handlePauseDownload = async () => {
    try {
      await pauseModelDownload();
    } catch (error) {
      showError(error);
    }
  };

  const beginRecording = async () => {
    if (!consent) {
      Alert.alert(
        "Consent required",
        "Confirm that this is your voice, or a voice you have permission to clone.",
      );
      return;
    }
    setRecordBusy(true);
    try {
      const permission = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
        {
          title: "Microphone permission",
          message:
            "Vaani Studio records a short sample locally to create your private voice.",
          buttonPositive: "Allow",
          buttonNegative: "Not now",
        },
      );
      if (permission !== PermissionsAndroid.RESULTS.GRANTED) {
        throw new Error(
          "Microphone permission is needed to record your voice sample",
        );
      }
      const fileUri = `${paths.voicesUri}voice-${fileSafeTimestamp()}.wav`;
      const status = await getNativeAudio().startRecording(fileUri);
      setRecording(status);
      recordingTimer.current = setInterval(async () => {
        try {
          const next = await getNativeAudio().getRecordingStatus();
          setRecording(next);
          if (next.durationMs >= 8_000 && !stoppingRecording.current)
            await finishRecording();
        } catch {}
      }, 120);
    } catch (error) {
      showError(error, "Could not record");
    } finally {
      setRecordBusy(false);
    }
  };

  const finishRecording = async () => {
    if (stoppingRecording.current) return;
    stoppingRecording.current = true;
    setRecordBusy(true);
    if (recordingTimer.current) {
      clearInterval(recordingTimer.current);
      recordingTimer.current = null;
    }
    try {
      const result = await getNativeAudio().stopRecording();
      setRecording(null);
      if (result.durationMs < 2_500) {
        await FileSystem.deleteAsync(result.fileUri, { idempotent: true });
        throw new Error(
          "That sample was too short. Speak naturally for 3–6 seconds.",
        );
      }
      if (result.clippedPercent > 5) {
        await FileSystem.deleteAsync(result.fileUri, { idempotent: true });
        throw new Error(
          "The sample was too loud and distorted. Move the phone slightly farther away and retry.",
        );
      }
      await adoptVoice({
        fileUri: result.fileUri,
        durationMs: result.durationMs,
        sampleRate: result.sampleRate,
        source: "recorded",
      });
      if (result.clippedPercent > 1) {
        Alert.alert(
          "Voice saved",
          "The sample works, but recording a little more quietly may improve the clone.",
        );
      }
    } catch (error) {
      showError(error, "Voice sample not saved");
    } finally {
      stoppingRecording.current = false;
      setRecordBusy(false);
    }
  };

  const adoptVoice = async ({
    fileUri,
    durationMs,
    sampleRate,
    source,
  }: {
    fileUri: string;
    durationMs: number;
    sampleRate: number;
    source: VoiceProfile["source"];
  }) => {
    const profile: VoiceProfile = {
      name: "My Voice",
      fileUri,
      durationMs,
      sampleRate,
      source,
      createdAt: Date.now(),
      consented: true,
    };
    const previous = voice;
    await saveVoiceProfile(profile);
    setVoice(profile);
    initializedVoice.current = "";
    if (previous?.fileUri && previous.fileUri !== fileUri) {
      await FileSystem.deleteAsync(previous.fileUri, {
        idempotent: true,
      }).catch(() => {});
    }
  };

  const importVoice = async () => {
    if (!consent) {
      Alert.alert(
        "Consent required",
        "Confirm that you own or have permission to clone the selected voice.",
      );
      return;
    }
    setRecordBusy(true);
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ["audio/wav", "audio/x-wav", "audio/*"],
        copyToCacheDirectory: true,
        multiple: false,
      });
      if (result.canceled) return;
      const source = result.assets[0];
      if (!source) return;
      const info = await getNativeAudio().inspectWav(source.uri);
      if (!info.valid)
        throw new Error(
          info.reason || "Choose an uncompressed 16-bit PCM WAV file",
        );
      if (info.durationMs < 2_500 || info.durationMs > 10_000) {
        throw new Error("Choose a clean voice sample between 3 and 10 seconds");
      }
      const destination = `${paths.voicesUri}voice-${fileSafeTimestamp()}.wav`;
      await FileSystem.copyAsync({ from: source.uri, to: destination });
      await adoptVoice({
        fileUri: destination,
        durationMs: info.durationMs,
        sampleRate: info.sampleRate,
        source: "imported",
      });
    } catch (error) {
      showError(error, "Could not import voice");
    } finally {
      setRecordBusy(false);
    }
  };

  const playOrToggle = async (fileUri: string) => {
    try {
      if (playingUri === fileUri && playback?.isLoaded) {
        const next = playback.isPlaying
          ? await getNativeAudio().pausePlayback()
          : await getNativeAudio().resumePlayback();
        setPlayback(next);
        return;
      }
      const next = await getNativeAudio().startPlayback(fileUri);
      setPlayingUri(fileUri);
      setPlayback(next);
    } catch (error) {
      showError(error, "Could not play audio");
    }
  };

  const shareFile = async (fileUri: string) => {
    try {
      if (!(await Sharing.isAvailableAsync()))
        throw new Error("Sharing is not available on this phone");
      await Sharing.shareAsync(fileUri, {
        mimeType: "audio/wav",
        dialogTitle: "Share Vaani Studio audio",
        UTI: "com.microsoft.waveform-audio",
      });
    } catch (error) {
      showError(error, "Could not share audio");
    }
  };

  const handleGenerate = async () => {
    if (!modelReady || !voice) {
      setSetupDismissed(false);
      return;
    }
    if (speechText.length < 2) {
      Alert.alert(
        "Add text",
        "Enter the words you want Vaani Studio to speak.",
      );
      return;
    }
    setGenerating(true);
    setLastGenerated(null);
    setGenerationProgress(0.01);
    setGenerationStatus("Starting the private offline engine…");
    const outputUri = `${paths.outputsUri}Vaani-${fileSafeTimestamp()}.wav`;
    const language = engineLanguage(mode);
    try {
      await activateKeepAwakeAsync("vaani-generation");
      const ttsEngine = getTtsEngine();
      const voiceKey = voice.fileUri;
      if (initializedVoice.current !== voiceKey) {
        await ttsEngine.initialize({
          modelDir: getModelPath(),
          voicePath: uriToPath(voice.fileUri),
          language: language.language,
          onStatus: (message) => {
            setGenerationStatus(
              message.message || "Opening the offline model…",
            );
            setGenerationProgress((current) =>
              Math.max(
                current,
                message.stage === "loading_model" ? 0.05 : 0.025,
              ),
            );
          },
        });
        initializedVoice.current = voiceKey;
      }

      setGenerationStatus(
        "Generating on your phone—first use can take several minutes…",
      );
      setGenerationProgress(0.08);
      const result = await ttsEngine.generate({
        text: speechText,
        outputPath: uriToPath(outputUri),
        language: language.language,
        locale: language.locale,
        onProgress: (message: EngineMessage) => {
          if (message.type === "status")
            setGenerationStatus(message.message || "Preparing…");
          if (message.type === "progress") {
            setGenerationProgress(
              Math.max(0.08, Number(message.progress) || 0.08),
            );
            setGenerationStatus(
              message.chunks
                ? `Creating audio… ${message.chunks} section${message.chunks === 1 ? "" : "s"} ready`
                : "Creating audio locally…",
            );
          }
        },
      });

      const item: AudioItem = {
        id: `${Date.now()}`,
        title: makeTitle(speechText),
        fileUri: outputUri,
        createdAt: Date.now(),
        durationMs: Number(result.durationMs) || 0,
        bytes: Number(result.bytes) || 0,
        language: mode,
        characters: speechText.length,
        aiGenerated: true,
      };
      const next = await addAudioItem(item);
      setLibrary(next);
      setLastGenerated(item);
      setGenerationProgress(1);
      setGenerationStatus("Audio ready");
    } catch (error) {
      if (!isGenerationCancelled(error)) {
        showError(error, "Generation failed");
      }
      setGenerationStatus("");
      setGenerationProgress(0);
    } finally {
      setGenerating(false);
      await deactivateKeepAwake("vaani-generation").catch(() => {});
    }
  };

  const cancelGeneration = async () => {
    setGenerationStatus("Cancelling…");
    try {
      await getTtsEngine().cancel();
    } catch (error) {
      showError(error, "Could not cancel generation");
    }
  };

  const deleteAudio = (item: AudioItem) => {
    Alert.alert(
      "Delete this audio?",
      "This permanently removes the WAV file from your phone.",
      [
        { text: "Keep", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            if (playingUri === item.fileUri) {
              await getNativeAudio()
                .stopPlayback()
                .catch(() => {});
              setPlayingUri(null);
            }
            await FileSystem.deleteAsync(item.fileUri, { idempotent: true });
            const next = await removeAudioItem(item.id);
            setLibrary(next);
            if (lastGenerated?.id === item.id) setLastGenerated(null);
          },
        },
      ],
    );
  };

  const deleteDownloadedModel = () => {
    Alert.alert(
      "Remove offline model?",
      "You will need to download about 830 MB again before generating more audio. Your voice and saved WAV files will stay.",
      [
        { text: "Keep", style: "cancel" },
        {
          text: "Remove",
          style: "destructive",
          onPress: async () => {
            terminateTtsEngineIfLoaded();
            initializedVoice.current = "";
            await removeModel();
            setModelReady(false);
            setModelBytes(0);
            setSetupDismissed(false);
          },
        },
      ],
    );
  };

  if (!hydrated) {
    return (
      <SafeAreaProvider>
        <View style={styles.loadingScreen}>
          <BrandMark large />
          <ActivityIndicator color={colors.saffron} size="large" />
          <Text style={styles.loadingText}>Preparing your private studio…</Text>
        </View>
      </SafeAreaProvider>
    );
  }

  return (
    <SafeAreaProvider>
      <StatusBar style="light" backgroundColor={colors.green} />
      <SafeAreaView edges={["top"]} style={styles.safeArea}>
        <AppHeader modelReady={modelReady} />
        {showSetup ? (
          <SetupScreen
            consent={consent}
            onConsent={handleConsent}
            modelReady={modelReady}
            modelBytes={modelBytes}
            downloading={downloading}
            downloadProgress={downloadProgress}
            onDownload={handleDownload}
            onPauseDownload={handlePauseDownload}
            voice={voice}
            recording={recording}
            recordBusy={recordBusy}
            onRecord={beginRecording}
            onStopRecord={finishRecording}
            onImport={importVoice}
            onPlay={playOrToggle}
            isVoicePlaying={
              !!voice && playingUri === voice.fileUri && !!playback?.isPlaying
            }
            onContinue={() => setSetupDismissed(true)}
          />
        ) : (
          <>
            <KeyboardAvoidingView
              behavior={Platform.OS === "ios" ? "padding" : undefined}
              style={styles.main}
            >
              {tab === "create" ? (
                <CreateScreen
                  draft={draft}
                  setDraft={setDraft}
                  mode={mode}
                  setMode={setMode}
                  improveHinglish={improveHinglish}
                  setImproveHinglish={setImproveHinglish}
                  speechText={speechText}
                  voice={voice}
                  generating={generating}
                  generationProgress={generationProgress}
                  generationStatus={generationStatus}
                  lastGenerated={lastGenerated}
                  onGenerate={handleGenerate}
                  onCancel={cancelGeneration}
                  onPlay={playOrToggle}
                  onShare={shareFile}
                  playingUri={playingUri}
                  playback={playback}
                />
              ) : null}
              {tab === "voice" ? (
                <VoiceScreen
                  voice={voice}
                  consent={consent}
                  recording={recording}
                  recordBusy={recordBusy}
                  onRecord={beginRecording}
                  onStopRecord={finishRecording}
                  onImport={importVoice}
                  onPlay={playOrToggle}
                  isPlaying={
                    !!voice &&
                    playingUri === voice.fileUri &&
                    !!playback?.isPlaying
                  }
                  modelBytes={modelBytes}
                  onRemoveModel={deleteDownloadedModel}
                />
              ) : null}
              {tab === "library" ? (
                <LibraryScreen
                  items={library}
                  playingUri={playingUri}
                  playback={playback}
                  onPlay={playOrToggle}
                  onShare={shareFile}
                  onDelete={deleteAudio}
                />
              ) : null}
            </KeyboardAvoidingView>
            <BottomTabs
              current={tab}
              onChange={setTab}
              libraryCount={library.length}
            />
          </>
        )}
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

function AppHeader({ modelReady }: { modelReady: boolean }) {
  return (
    <View style={styles.header}>
      <BrandMark />
      <View style={styles.offlineBadge}>
        <View
          style={[styles.offlineDot, !modelReady && styles.offlineDotSetup]}
        />
        <Text style={styles.offlineText}>
          {modelReady ? "OFFLINE READY" : "SETUP"}
        </Text>
      </View>
    </View>
  );
}

function BrandMark({ large = false }: { large?: boolean }) {
  return (
    <View style={styles.brandRow}>
      <View style={[styles.brandIcon, large && styles.brandIconLarge]}>
        <View style={styles.waveOne} />
        <View style={styles.waveTwo} />
        <View style={styles.waveThree} />
      </View>
      <View>
        <Text style={[styles.brandName, large && styles.brandNameLarge]}>
          Vaani Studio
        </Text>
        <Text style={[styles.brandSub, large && styles.brandSubDark]}>
          PRIVATE VOICE • ON DEVICE
        </Text>
      </View>
    </View>
  );
}

function SetupScreen(props: {
  consent: boolean;
  onConsent: () => void;
  modelReady: boolean;
  modelBytes: number;
  downloading: boolean;
  downloadProgress: ModelProgress | null;
  onDownload: () => void;
  onPauseDownload: () => void;
  voice: VoiceProfile | null;
  recording: RecordingStatus | null;
  recordBusy: boolean;
  onRecord: () => void;
  onStopRecord: () => void;
  onImport: () => void;
  onPlay: (uri: string) => void;
  isVoicePlaying: boolean;
  onContinue: () => void;
}) {
  const percent = Math.round(
    (props.downloadProgress?.overallProgress || 0) * 100,
  );
  const allReady = props.consent && props.modelReady && !!props.voice;
  return (
    <ScrollView
      contentContainerStyle={styles.setupContent}
      keyboardShouldPersistTaps="handled"
    >
      <View style={styles.hero}>
        <Pill tone="saffron">One-time private setup</Pill>
        <Text style={styles.heroTitle}>
          Your words.{`\n`}Your voice. No cloud.
        </Text>
        <Text style={styles.heroText}>
          Download once on Wi-Fi, record a short sample, then create audio
          entirely on this phone.
        </Text>
        <View style={styles.heroFacts}>
          <Fact icon="₹0" label="Always free" />
          <Fact icon="⌁" label="Works offline" />
          <Fact icon="▣" label="Files stay local" />
        </View>
      </View>

      <Card style={styles.setupCard}>
        <View style={styles.stepHeader}>
          <StepNumber value="1" done={props.consent} />
          <View style={styles.stepCopy}>
            <Text style={styles.cardTitle}>Voice permission</Text>
            <Text style={styles.cardSubtitle}>
              Voice cloning must be used responsibly.
            </Text>
          </View>
        </View>
        <CheckRow
          checked={props.consent}
          onPress={props.onConsent}
          text="I will clone only my own voice, or a voice whose owner has clearly authorized me to use it."
        />
      </Card>

      <Card style={styles.setupCard}>
        <View style={styles.stepHeader}>
          <StepNumber value="2" done={props.modelReady} />
          <View style={styles.stepCopy}>
            <Text style={styles.cardTitle}>
              Install the offline voice model
            </Text>
            <Text style={styles.cardSubtitle}>
              About 830 MB • Wi-Fi recommended • one time
            </Text>
          </View>
        </View>
        {props.modelReady ? (
          <>
            <InlineNotice>
              Model verified and stored on this phone (
              {formatBytes(props.modelBytes)}).
            </InlineNotice>
            <View style={styles.readyLine}>
              <Text style={styles.readyCheck}>✓</Text>
              <Text style={styles.readyText}>
                Internet is no longer needed for generation
              </Text>
            </View>
          </>
        ) : props.downloading ? (
          <View style={styles.stackGap}>
            <ProgressBar value={props.downloadProgress?.overallProgress || 0} />
            <View style={styles.progressLabels}>
              <Text style={styles.progressTitle}>
                {props.downloadProgress?.message || "Starting download…"}
              </Text>
              <Text style={styles.progressPercent}>{percent}%</Text>
            </View>
            <Text style={styles.helperText}>
              Keep Vaani Studio open. You can pause and continue later.
            </Text>
            <Button
              title="Pause download"
              variant="ghost"
              compact
              onPress={props.onPauseDownload}
            />
          </View>
        ) : (
          <View style={styles.stackGap}>
            <InlineNotice tone="saffron">
              Keep at least 1.25 GB free while installing. The final model uses
              about 830 MB.
            </InlineNotice>
            <Button
              title={
                props.downloadProgress?.phase === "paused"
                  ? "Continue download"
                  : "Download offline model"
              }
              onPress={props.onDownload}
            />
          </View>
        )}
      </Card>

      <Card style={styles.setupCard}>
        <View style={styles.stepHeader}>
          <StepNumber value="3" done={!!props.voice} />
          <View style={styles.stepCopy}>
            <Text style={styles.cardTitle}>Create your private voice</Text>
            <Text style={styles.cardSubtitle}>
              3–6 seconds in a quiet room works best
            </Text>
          </View>
        </View>
        {!props.consent ? (
          <InlineNotice tone="saffron">
            Complete the permission statement above first.
          </InlineNotice>
        ) : props.recording ? (
          <RecordingPanel
            status={props.recording}
            onStop={props.onStopRecord}
          />
        ) : props.voice ? (
          <View style={styles.stackGap}>
            <VoiceSummary voice={props.voice} />
            <View style={styles.twoButtons}>
              <View style={styles.flexButton}>
                <Button
                  title={props.isVoicePlaying ? "Pause sample" : "Play sample"}
                  variant="secondary"
                  compact
                  onPress={() => props.onPlay(props.voice!.fileUri)}
                />
              </View>
              <View style={styles.flexButton}>
                <Button
                  title="Record again"
                  variant="ghost"
                  compact
                  onPress={props.onRecord}
                />
              </View>
            </View>
          </View>
        ) : (
          <View style={styles.stackGap}>
            <View style={styles.sampleBox}>
              <Text style={styles.sampleLabel}>READ THIS NATURALLY</Text>
              <Text style={styles.sampleText}>{sampleLine}</Text>
            </View>
            <Button
              title="●  Record my voice"
              busy={props.recordBusy}
              onPress={props.onRecord}
            />
            <Button
              title="Import a PCM WAV instead"
              variant="ghost"
              compact
              onPress={props.onImport}
            />
          </View>
        )}
      </Card>

      {allReady ? (
        <View style={styles.setupButton}>
          <Button title="Open Vaani Studio" onPress={props.onContinue} />
        </View>
      ) : null}
      <Text style={styles.setupFootnote}>
        MoneyClarityTech • No account • No subscription • No analytics
      </Text>
    </ScrollView>
  );
}

function CreateScreen(props: {
  draft: string;
  setDraft: (text: string) => void;
  mode: LanguageMode;
  setMode: (mode: LanguageMode) => void;
  improveHinglish: boolean;
  setImproveHinglish: (value: boolean) => void;
  speechText: string;
  voice: VoiceProfile;
  generating: boolean;
  generationProgress: number;
  generationStatus: string;
  lastGenerated: AudioItem | null;
  onGenerate: () => void;
  onCancel: () => void;
  onPlay: (uri: string) => void;
  onShare: (uri: string) => void;
  playingUri: string | null;
  playback: PlaybackStatus | null;
}) {
  const transformed =
    props.mode === "hinglish" && props.speechText !== props.draft.trim();
  return (
    <ScrollView
      contentContainerStyle={styles.screenContent}
      keyboardShouldPersistTaps="handled"
    >
      <SectionTitle
        title="Create audio"
        subtitle="Paste a script and hear it in your private cloned voice."
      />

      <View style={styles.segmented}>
        {(["hinglish", "hindi", "english"] as LanguageMode[]).map((value) => (
          <Pressable
            key={value}
            accessibilityRole="button"
            accessibilityState={{ selected: props.mode === value }}
            onPress={() => props.setMode(value)}
            style={[
              styles.segment,
              props.mode === value && styles.segmentActive,
            ]}
          >
            <Text
              style={[
                styles.segmentText,
                props.mode === value && styles.segmentTextActive,
              ]}
            >
              {value === "hinglish"
                ? "Hinglish"
                : value === "hindi"
                  ? "हिन्दी"
                  : "English"}
            </Text>
          </Pressable>
        ))}
      </View>

      <Card style={styles.editorCard}>
        <View style={styles.editorHeader}>
          <Text style={styles.editorLabel}>SCRIPT</Text>
          <Pressable
            disabled={!props.draft || props.generating}
            onPress={() => props.setDraft("")}
          >
            <Text style={styles.clearText}>Clear</Text>
          </Pressable>
        </View>
        <TextInput
          accessibilityLabel="Text to convert to audio"
          editable={!props.generating}
          multiline
          onChangeText={props.setDraft}
          placeholder="Type or paste your narration here…"
          placeholderTextColor="#879892"
          selectionColor={colors.saffron}
          style={styles.editor}
          textAlignVertical="top"
          value={props.draft}
          maxLength={8_000}
        />
        <Text style={styles.characterCount}>
          {props.draft.length.toLocaleString()} / 8,000 characters
        </Text>
      </Card>

      {props.mode === "hinglish" ? (
        <Card style={styles.compactCard}>
          <View style={styles.switchRow}>
            <View style={styles.switchCopy}>
              <Text style={styles.switchTitle}>Improve Roman Hindi</Text>
              <Text style={styles.switchSubtitle}>
                Converts common Hindi words for clearer pronunciation.
              </Text>
            </View>
            <Switch
              value={props.improveHinglish}
              onValueChange={props.setImproveHinglish}
              trackColor={{ false: "#CCD8D3", true: colors.mint }}
              thumbColor={props.improveHinglish ? colors.green : colors.white}
            />
          </View>
          {transformed ? (
            <View style={styles.previewBox}>
              <Text style={styles.previewLabel}>SPEECH-READY PREVIEW</Text>
              <Text numberOfLines={4} style={styles.previewText}>
                {props.speechText}
              </Text>
            </View>
          ) : null}
        </Card>
      ) : null}

      <View style={styles.voiceChipRow}>
        <View style={styles.miniAvatar}>
          <Text style={styles.miniAvatarText}>V</Text>
        </View>
        <View style={styles.voiceChipCopy}>
          <Text style={styles.voiceChipTitle}>{props.voice.name}</Text>
          <Text style={styles.voiceChipSub}>
            {formatDuration(props.voice.durationMs)} sample • stays on device
          </Text>
        </View>
        <Pill>Private</Pill>
      </View>

      {props.generating ? (
        <Card style={styles.generationCard}>
          <View style={styles.generationTitleRow}>
            <View style={styles.pulseDot} />
            <Text style={styles.generationTitle}>
              Working entirely on this phone
            </Text>
          </View>
          <ProgressBar value={props.generationProgress} />
          <Text style={styles.generationStatus}>{props.generationStatus}</Text>
          <InlineNotice tone="saffron">
            Keep the app open. Voice cloning can be slower than playback,
            especially the first time.
          </InlineNotice>
          <Button
            title="Cancel"
            variant="ghost"
            compact
            onPress={props.onCancel}
          />
        </Card>
      ) : (
        <Button
          title="Generate private audio"
          disabled={!props.draft.trim()}
          onPress={props.onGenerate}
        />
      )}

      {props.lastGenerated ? (
        <Card style={styles.resultCard}>
          <View style={styles.resultTop}>
            <View style={styles.successCircle}>
              <Text style={styles.successMark}>✓</Text>
            </View>
            <View style={styles.resultCopy}>
              <Text style={styles.resultTitle}>Audio ready</Text>
              <Text style={styles.resultSub}>
                {formatDuration(props.lastGenerated.durationMs)} • WAV •
                AI-generated
              </Text>
            </View>
          </View>
          <View style={styles.twoButtons}>
            <View style={styles.flexButton}>
              <Button
                title={
                  props.playingUri === props.lastGenerated.fileUri &&
                  props.playback?.isPlaying
                    ? "Pause"
                    : "Play"
                }
                variant="secondary"
                compact
                onPress={() => props.onPlay(props.lastGenerated!.fileUri)}
              />
            </View>
            <View style={styles.flexButton}>
              <Button
                title="Share WAV"
                compact
                onPress={() => props.onShare(props.lastGenerated!.fileUri)}
              />
            </View>
          </View>
        </Card>
      ) : null}
    </ScrollView>
  );
}

function VoiceScreen(props: {
  voice: VoiceProfile;
  consent: boolean;
  recording: RecordingStatus | null;
  recordBusy: boolean;
  onRecord: () => void;
  onStopRecord: () => void;
  onImport: () => void;
  onPlay: (uri: string) => void;
  isPlaying: boolean;
  modelBytes: number;
  onRemoveModel: () => void;
}) {
  return (
    <ScrollView contentContainerStyle={styles.screenContent}>
      <SectionTitle
        title="My voice"
        subtitle="Your sample never leaves this phone."
      />
      <Card>
        {props.recording ? (
          <RecordingPanel
            status={props.recording}
            onStop={props.onStopRecord}
          />
        ) : (
          <View style={styles.stackGap}>
            <VoiceSummary voice={props.voice} large />
            <View style={styles.sampleBox}>
              <Text style={styles.sampleLabel}>FOR A NEW RECORDING, READ</Text>
              <Text style={styles.sampleText}>{sampleLine}</Text>
            </View>
            <Button
              title={
                props.isPlaying ? "Pause voice sample" : "Play voice sample"
              }
              variant="secondary"
              onPress={() => props.onPlay(props.voice.fileUri)}
            />
            <Button
              title="Record a better sample"
              busy={props.recordBusy}
              onPress={props.onRecord}
            />
            <Button
              title="Import PCM WAV"
              variant="ghost"
              compact
              onPress={props.onImport}
            />
          </View>
        )}
      </Card>

      <Card>
        <Text style={styles.cardTitle}>A strong voice sample</Text>
        <View style={styles.tipsList}>
          <Tip text="Speak one natural sentence for 3–6 seconds" />
          <Tip text="Use a quiet room and keep the phone 15–25 cm away" />
          <Tip text="Avoid music, echo, whispers, or multiple speakers" />
          <Tip text="Do not reuse the exact words in your generation script" />
        </View>
      </Card>

      <Card>
        <View style={styles.settingsRow}>
          <View style={styles.settingsCopy}>
            <Text style={styles.cardTitle}>Offline model</Text>
            <Text style={styles.cardSubtitle}>
              {formatBytes(props.modelBytes)} stored privately
            </Text>
          </View>
          <Pill>Verified</Pill>
        </View>
        <Button
          title="Remove downloaded model"
          variant="danger"
          compact
          onPress={props.onRemoveModel}
        />
      </Card>
    </ScrollView>
  );
}

function LibraryScreen(props: {
  items: AudioItem[];
  playingUri: string | null;
  playback: PlaybackStatus | null;
  onPlay: (uri: string) => void;
  onShare: (uri: string) => void;
  onDelete: (item: AudioItem) => void;
}) {
  return (
    <ScrollView contentContainerStyle={styles.screenContent}>
      <SectionTitle
        title="Audio library"
        subtitle="WAV files saved locally and ready for your editor."
      />
      {props.items.length === 0 ? (
        <Card style={styles.emptyCard}>
          <Text style={styles.emptyIcon}>⌁</Text>
          <Text style={styles.emptyTitle}>No audio yet</Text>
          <Text style={styles.emptyText}>
            Your generated files will appear here.
          </Text>
        </Card>
      ) : (
        props.items.map((item) => {
          const active = props.playingUri === item.fileUri;
          return (
            <Card key={item.id} style={styles.libraryCard}>
              <View style={styles.libraryTop}>
                <Pressable
                  onPress={() => props.onPlay(item.fileUri)}
                  style={[styles.playCircle, active && styles.playCircleActive]}
                >
                  <Text
                    style={[
                      styles.playSymbol,
                      active && styles.playSymbolActive,
                    ]}
                  >
                    {active && props.playback?.isPlaying ? "Ⅱ" : "▶"}
                  </Text>
                </Pressable>
                <View style={styles.libraryCopy}>
                  <Text numberOfLines={2} style={styles.libraryTitle}>
                    {item.title}
                  </Text>
                  <Text style={styles.libraryMeta}>
                    {formatDuration(item.durationMs)} •{" "}
                    {formatBytes(item.bytes)} • {languageLabel(item.language)}
                  </Text>
                  <Text style={styles.libraryDate}>
                    {formatDate(item.createdAt)} • AI-generated
                  </Text>
                </View>
              </View>
              {active && props.playback?.isLoaded ? (
                <ProgressBar
                  value={
                    props.playback.positionMs /
                    Math.max(1, props.playback.durationMs)
                  }
                  color={colors.green}
                />
              ) : null}
              <View style={styles.libraryActions}>
                <Button
                  title="Share"
                  variant="secondary"
                  compact
                  onPress={() => props.onShare(item.fileUri)}
                />
                <Button
                  title="Delete"
                  variant="ghost"
                  compact
                  onPress={() => props.onDelete(item)}
                />
              </View>
            </Card>
          );
        })
      )}
    </ScrollView>
  );
}

function BottomTabs({
  current,
  onChange,
  libraryCount,
}: {
  current: Tab;
  onChange: (tab: Tab) => void;
  libraryCount: number;
}) {
  return (
    <SafeAreaView edges={["bottom"]} style={styles.tabSafe}>
      <View style={styles.tabs}>
        <TabButton
          icon="✦"
          label="Create"
          selected={current === "create"}
          onPress={() => onChange("create")}
        />
        <TabButton
          icon="◉"
          label="My voice"
          selected={current === "voice"}
          onPress={() => onChange("voice")}
        />
        <TabButton
          icon="▤"
          label="Library"
          badge={libraryCount}
          selected={current === "library"}
          onPress={() => onChange("library")}
        />
      </View>
    </SafeAreaView>
  );
}

function TabButton({
  icon,
  label,
  selected,
  badge,
  onPress,
}: {
  icon: string;
  label: string;
  selected: boolean;
  badge?: number;
  onPress: () => void;
}) {
  return (
    <Pressable
      accessibilityRole="tab"
      accessibilityState={{ selected }}
      onPress={onPress}
      style={styles.tabButton}
    >
      <View>
        <Text style={[styles.tabIcon, selected && styles.tabIconSelected]}>
          {icon}
        </Text>
        {badge ? (
          <View style={styles.tabBadge}>
            <Text style={styles.tabBadgeText}>
              {badge > 99 ? "99+" : badge}
            </Text>
          </View>
        ) : null}
      </View>
      <Text style={[styles.tabLabel, selected && styles.tabLabelSelected]}>
        {label}
      </Text>
    </Pressable>
  );
}

function RecordingPanel({
  status,
  onStop,
}: {
  status: RecordingStatus;
  onStop: () => void;
}) {
  const targetProgress = Math.min(1, status.durationMs / 6_000);
  const loudness = Math.min(1, status.rms * 6);
  return (
    <View style={styles.recordingPanel}>
      <View style={styles.recordingHeader}>
        <View style={styles.recordDot} />
        <Text style={styles.recordingTitle}>Recording locally</Text>
        <Text style={styles.recordTime}>
          {(status.durationMs / 1_000).toFixed(1)}s
        </Text>
      </View>
      <ProgressBar
        value={targetProgress}
        color={targetProgress >= 0.5 ? colors.success : colors.saffron}
      />
      <View style={styles.meterTrack}>
        <View style={[styles.meterFill, { width: `${loudness * 100}%` }]} />
      </View>
      <Text style={styles.helperText}>
        {status.durationMs < 3_000
          ? "Keep speaking…"
          : status.durationMs <= 6_500
            ? "Great length—you can stop now."
            : "Finishing shortly…"}
      </Text>
      <Button title="■  Stop and save" onPress={onStop} />
    </View>
  );
}

function VoiceSummary({
  voice,
  large = false,
}: {
  voice: VoiceProfile;
  large?: boolean;
}) {
  return (
    <View style={styles.voiceSummary}>
      <View style={[styles.voiceAvatar, large && styles.voiceAvatarLarge]}>
        <Text style={styles.voiceAvatarText}>V</Text>
      </View>
      <View style={styles.voiceSummaryCopy}>
        <Text style={styles.voiceName}>{voice.name}</Text>
        <Text style={styles.voiceMeta}>
          {formatDuration(voice.durationMs)} • {voice.sampleRate / 1000} kHz •{" "}
          {voice.source}
        </Text>
      </View>
      <Pill>Local</Pill>
    </View>
  );
}

function StepNumber({ value, done }: { value: string; done: boolean }) {
  return (
    <View style={[styles.stepNumber, done && styles.stepNumberDone]}>
      <Text style={styles.stepNumberText}>{done ? "✓" : value}</Text>
    </View>
  );
}

function Fact({ icon, label }: { icon: string; label: string }) {
  return (
    <View style={styles.fact}>
      <Text style={styles.factIcon}>{icon}</Text>
      <Text style={styles.factLabel}>{label}</Text>
    </View>
  );
}

function Tip({ text }: { text: string }) {
  return (
    <View style={styles.tipRow}>
      <Text style={styles.tipCheck}>✓</Text>
      <Text style={styles.tipText}>{text}</Text>
    </View>
  );
}

function makeTitle(text: string) {
  const first = text.split(/[.!?।\n]/)[0]?.trim() || "Vaani audio";
  return first.length > 58 ? `${first.slice(0, 55)}…` : first;
}

function languageLabel(mode: LanguageMode) {
  return mode === "hinglish"
    ? "Hinglish"
    : mode === "hindi"
      ? "Hindi"
      : "English";
}

function formatDate(timestamp: number) {
  return new Date(timestamp).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function showError(error: unknown, title = "Something went wrong") {
  const message = error instanceof Error ? error.message : String(error);
  Alert.alert(title, message);
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: colors.cream },
  main: { flex: 1 },
  loadingScreen: {
    flex: 1,
    backgroundColor: colors.cream,
    alignItems: "center",
    justifyContent: "center",
    gap: 22,
  },
  loadingText: { color: colors.muted, fontSize: 14, fontWeight: "600" },
  header: {
    minHeight: 72,
    backgroundColor: colors.green,
    paddingHorizontal: 18,
    paddingVertical: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  brandIcon: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: colors.mint,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 3,
  },
  brandIconLarge: { width: 54, height: 54, borderRadius: 17 },
  waveOne: {
    width: 3,
    height: 11,
    backgroundColor: colors.green,
    borderRadius: 3,
  },
  waveTwo: {
    width: 3,
    height: 22,
    backgroundColor: colors.green,
    borderRadius: 3,
  },
  waveThree: {
    width: 3,
    height: 15,
    backgroundColor: colors.green,
    borderRadius: 3,
  },
  brandName: {
    color: colors.white,
    fontSize: 18,
    fontWeight: "900",
    letterSpacing: -0.3,
  },
  brandNameLarge: { color: colors.green, fontSize: 24 },
  brandSub: {
    color: "#B6D8CE",
    fontSize: 8,
    fontWeight: "800",
    letterSpacing: 1.1,
    marginTop: 1,
  },
  brandSubDark: { color: colors.muted },
  offlineBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    borderWidth: 1,
    borderColor: "#387068",
    borderRadius: radii.pill,
    paddingHorizontal: 9,
    paddingVertical: 6,
  },
  offlineDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: colors.mint,
  },
  offlineDotSetup: { backgroundColor: colors.saffron },
  offlineText: {
    color: colors.white,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 0.8,
  },
  setupContent: { paddingBottom: 36, gap: 14 },
  setupCard: { marginHorizontal: 14 },
  setupButton: { marginHorizontal: 14 },
  hero: {
    backgroundColor: colors.green,
    paddingHorizontal: 22,
    paddingTop: 20,
    paddingBottom: 28,
    gap: 13,
  },
  heroTitle: {
    color: colors.white,
    fontSize: 36,
    lineHeight: 40,
    fontWeight: "900",
    letterSpacing: -1.3,
  },
  heroText: { color: "#D5EAE3", fontSize: 15, lineHeight: 22, maxWidth: 360 },
  heroFacts: { flexDirection: "row", gap: 9, marginTop: 4 },
  fact: {
    flex: 1,
    minHeight: 63,
    borderRadius: 14,
    backgroundColor: "#0B4A43",
    alignItems: "center",
    justifyContent: "center",
    padding: 7,
    gap: 3,
  },
  factIcon: { color: colors.mint, fontSize: 16, fontWeight: "900" },
  factLabel: {
    color: colors.white,
    fontSize: 9,
    textAlign: "center",
    fontWeight: "700",
  },
  stepHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 16,
  },
  stepNumber: {
    width: 36,
    height: 36,
    borderRadius: 12,
    backgroundColor: colors.saffronSoft,
    alignItems: "center",
    justifyContent: "center",
  },
  stepNumberDone: { backgroundColor: colors.mintSoft },
  stepNumberText: { color: colors.green, fontSize: 16, fontWeight: "900" },
  stepCopy: { flex: 1 },
  cardTitle: {
    color: colors.ink,
    fontSize: 17,
    fontWeight: "900",
    letterSpacing: -0.2,
  },
  cardSubtitle: {
    color: colors.muted,
    fontSize: 12,
    lineHeight: 17,
    marginTop: 3,
  },
  stackGap: { gap: 12 },
  readyLine: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginTop: 13,
  },
  readyCheck: { color: colors.success, fontWeight: "900" },
  readyText: { color: colors.muted, fontSize: 12, fontWeight: "700" },
  progressLabels: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 8,
  },
  progressTitle: {
    flex: 1,
    color: colors.ink,
    fontSize: 12,
    fontWeight: "700",
  },
  progressPercent: { color: colors.green, fontSize: 13, fontWeight: "900" },
  helperText: { color: colors.muted, fontSize: 12, lineHeight: 18 },
  sampleBox: {
    backgroundColor: colors.cream,
    borderRadius: radii.medium,
    borderWidth: 1,
    borderColor: colors.border,
    padding: 15,
    gap: 7,
  },
  sampleLabel: {
    color: colors.muted,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 1,
  },
  sampleText: {
    color: colors.ink,
    fontSize: 18,
    lineHeight: 28,
    fontWeight: "700",
  },
  twoButtons: { flexDirection: "row", gap: 10 },
  flexButton: { flex: 1 },
  setupFootnote: {
    textAlign: "center",
    color: colors.muted,
    fontSize: 10,
    lineHeight: 16,
    marginHorizontal: 20,
    marginTop: 4,
  },
  screenContent: { padding: 18, paddingBottom: 32, gap: 15 },
  segmented: {
    flexDirection: "row",
    backgroundColor: "#E5EEE9",
    padding: 4,
    borderRadius: radii.medium,
  },
  segment: {
    flex: 1,
    minHeight: 42,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 12,
  },
  segmentActive: {
    backgroundColor: colors.white,
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 5,
    elevation: 1,
  },
  segmentText: { color: colors.muted, fontSize: 13, fontWeight: "800" },
  segmentTextActive: { color: colors.green },
  editorCard: { padding: 0, overflow: "hidden" },
  editorHeader: {
    paddingHorizontal: 16,
    paddingTop: 15,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  editorLabel: {
    color: colors.muted,
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1,
  },
  clearText: { color: colors.greenLight, fontSize: 12, fontWeight: "800" },
  editor: {
    minHeight: 210,
    maxHeight: 360,
    paddingHorizontal: 16,
    paddingVertical: 13,
    color: colors.ink,
    fontSize: 17,
    lineHeight: 26,
  },
  characterCount: {
    color: colors.muted,
    fontSize: 10,
    textAlign: "right",
    paddingHorizontal: 16,
    paddingBottom: 13,
  },
  compactCard: { padding: 15, gap: 12 },
  switchRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  switchCopy: { flex: 1 },
  switchTitle: { color: colors.ink, fontSize: 14, fontWeight: "800" },
  switchSubtitle: {
    color: colors.muted,
    fontSize: 11,
    lineHeight: 16,
    marginTop: 2,
  },
  previewBox: {
    backgroundColor: colors.cream,
    borderRadius: radii.small,
    padding: 12,
  },
  previewLabel: {
    color: colors.greenLight,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 0.8,
    marginBottom: 6,
  },
  previewText: { color: colors.ink, fontSize: 13, lineHeight: 20 },
  voiceChipRow: {
    flexDirection: "row",
    alignItems: "center",
    padding: 12,
    borderRadius: radii.medium,
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.border,
    gap: 10,
  },
  miniAvatar: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.saffronSoft,
    alignItems: "center",
    justifyContent: "center",
  },
  miniAvatarText: { color: "#A35F00", fontWeight: "900" },
  voiceChipCopy: { flex: 1 },
  voiceChipTitle: { color: colors.ink, fontSize: 13, fontWeight: "900" },
  voiceChipSub: { color: colors.muted, fontSize: 10, marginTop: 2 },
  generationCard: { gap: 13 },
  generationTitleRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  pulseDot: {
    width: 9,
    height: 9,
    borderRadius: 5,
    backgroundColor: colors.saffron,
  },
  generationTitle: { color: colors.ink, fontSize: 14, fontWeight: "900" },
  generationStatus: { color: colors.muted, fontSize: 12, lineHeight: 18 },
  resultCard: { gap: 15, borderColor: "#AFDFC9" },
  resultTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  successCircle: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: colors.mintSoft,
    alignItems: "center",
    justifyContent: "center",
  },
  successMark: { color: colors.success, fontSize: 20, fontWeight: "900" },
  resultCopy: { flex: 1 },
  resultTitle: { color: colors.ink, fontSize: 16, fontWeight: "900" },
  resultSub: { color: colors.muted, fontSize: 11, marginTop: 3 },
  voiceSummary: { flexDirection: "row", alignItems: "center", gap: 12 },
  voiceAvatar: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: colors.saffronSoft,
    alignItems: "center",
    justifyContent: "center",
  },
  voiceAvatarLarge: { width: 62, height: 62, borderRadius: 31 },
  voiceAvatarText: { color: "#A35F00", fontSize: 22, fontWeight: "900" },
  voiceSummaryCopy: { flex: 1 },
  voiceName: { color: colors.ink, fontSize: 17, fontWeight: "900" },
  voiceMeta: {
    color: colors.muted,
    fontSize: 11,
    marginTop: 3,
    textTransform: "capitalize",
  },
  tipsList: { gap: 12, marginTop: 14 },
  tipRow: { flexDirection: "row", gap: 9, alignItems: "flex-start" },
  tipCheck: { color: colors.success, fontWeight: "900" },
  tipText: { flex: 1, color: colors.ink, fontSize: 13, lineHeight: 19 },
  settingsRow: { flexDirection: "row", alignItems: "center", marginBottom: 16 },
  settingsCopy: { flex: 1 },
  emptyCard: { alignItems: "center", paddingVertical: 52 },
  emptyIcon: { color: colors.saffron, fontSize: 42, fontWeight: "900" },
  emptyTitle: {
    color: colors.ink,
    fontSize: 18,
    fontWeight: "900",
    marginTop: 10,
  },
  emptyText: { color: colors.muted, fontSize: 13, marginTop: 5 },
  libraryCard: { gap: 13 },
  libraryTop: { flexDirection: "row", gap: 12, alignItems: "center" },
  playCircle: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.mintSoft,
    alignItems: "center",
    justifyContent: "center",
  },
  playCircleActive: { backgroundColor: colors.green },
  playSymbol: {
    color: colors.green,
    fontSize: 16,
    fontWeight: "900",
    marginLeft: 2,
  },
  playSymbolActive: { color: colors.white, marginLeft: 0 },
  libraryCopy: { flex: 1 },
  libraryTitle: {
    color: colors.ink,
    fontSize: 15,
    lineHeight: 20,
    fontWeight: "900",
  },
  libraryMeta: { color: colors.muted, fontSize: 10, marginTop: 4 },
  libraryDate: { color: "#80918B", fontSize: 9, marginTop: 3 },
  libraryActions: { flexDirection: "row", gap: 9, justifyContent: "flex-end" },
  tabSafe: {
    backgroundColor: colors.white,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  tabs: { minHeight: 66, flexDirection: "row" },
  tabButton: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 4,
  },
  tabIcon: { color: "#899992", fontSize: 20, fontWeight: "800" },
  tabIconSelected: { color: colors.green },
  tabLabel: { color: "#899992", fontSize: 10, fontWeight: "700" },
  tabLabelSelected: { color: colors.green, fontWeight: "900" },
  tabBadge: {
    position: "absolute",
    right: -13,
    top: -4,
    minWidth: 17,
    height: 17,
    paddingHorizontal: 4,
    borderRadius: 9,
    backgroundColor: colors.saffron,
    alignItems: "center",
    justifyContent: "center",
  },
  tabBadgeText: { color: colors.white, fontSize: 8, fontWeight: "900" },
  recordingPanel: { gap: 13 },
  recordingHeader: { flexDirection: "row", alignItems: "center", gap: 8 },
  recordDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: "#E0322B",
  },
  recordingTitle: {
    flex: 1,
    color: colors.ink,
    fontSize: 15,
    fontWeight: "900",
  },
  recordTime: {
    color: colors.danger,
    fontSize: 17,
    fontVariant: ["tabular-nums"],
    fontWeight: "900",
  },
  meterTrack: {
    height: 5,
    borderRadius: 3,
    backgroundColor: "#E5ECE8",
    overflow: "hidden",
  },
  meterFill: { height: "100%", backgroundColor: colors.greenLight },
});
