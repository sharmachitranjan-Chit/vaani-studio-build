const { withGradleProperties } = require("expo/config-plugins");

module.exports = function withArm64Only(config) {
  return withGradleProperties(config, (nextConfig) => {
    const properties = nextConfig.modResults;
    const existing = properties.find(
      (item) =>
        item.type === "property" && item.key === "reactNativeArchitectures",
    );

    if (existing) {
      existing.value = "arm64-v8a";
    } else {
      properties.push({
        type: "property",
        key: "reactNativeArchitectures",
        value: "arm64-v8a",
      });
    }

    return nextConfig;
  });
};
