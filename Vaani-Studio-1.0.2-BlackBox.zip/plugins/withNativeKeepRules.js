const fs = require("fs");
const path = require("path");
const { withDangerousMod } = require("expo/config-plugins");

const marker = "# Vaani Studio native keep rules";
const rules = `
${marker}
-keep class com.moneyclaritytech.vaanistudio.audio.** { *; }
-keep class to.holepunch.bare.** { *; }
-keep class to.holepunch.bare.kit.** { *; }
-keep class to.holepunch.b4a.** { *; }
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}
`;

module.exports = function withNativeKeepRules(config) {
  return withDangerousMod(config, [
    "android",
    async (nextConfig) => {
      const target = path.join(
        nextConfig.modRequest.platformProjectRoot,
        "app",
        "proguard-rules.pro",
      );
      let current = "";
      try {
        current = await fs.promises.readFile(target, "utf8");
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
      }
      if (!current.includes(marker)) {
        await fs.promises.appendFile(target, rules, "utf8");
      }
      return nextConfig;
    },
  ]);
};
