export type RecordingStatus = {
  isRecording: boolean;
  durationMs: number;
  sampleRate: number;
  rms: number;
  peak: number;
  clippedPercent: number;
};

export type RecordingResult = RecordingStatus & {
  fileUri: string;
  bytes: number;
};

export type PlaybackStatus = {
  isLoaded: boolean;
  isPlaying: boolean;
  positionMs: number;
  durationMs: number;
};

export type WavInfo = {
  valid: boolean;
  format: number;
  channels: number;
  sampleRate: number;
  bitsPerSample: number;
  dataOffset: number;
  dataBytes: number;
  durationMs: number;
  reason: string;
};
