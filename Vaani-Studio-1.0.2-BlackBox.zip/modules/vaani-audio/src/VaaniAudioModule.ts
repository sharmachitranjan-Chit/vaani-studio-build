import { NativeModule, requireNativeModule } from "expo";

import type {
  PlaybackStatus,
  RecordingResult,
  RecordingStatus,
  WavInfo,
} from "./VaaniAudio.types";

declare class VaaniAudioModule extends NativeModule {
  startRecording(fileUri: string): Promise<RecordingStatus>;
  stopRecording(): Promise<RecordingResult>;
  getRecordingStatus(): Promise<RecordingStatus>;
  inspectWav(fileUri: string): Promise<WavInfo>;
  sha256File(fileUri: string): Promise<string>;
  startPlayback(fileUri: string): Promise<PlaybackStatus>;
  pausePlayback(): Promise<PlaybackStatus>;
  resumePlayback(): Promise<PlaybackStatus>;
  stopPlayback(): Promise<PlaybackStatus>;
  getPlaybackStatus(): Promise<PlaybackStatus>;
}

export default requireNativeModule<VaaniAudioModule>("VaaniAudio");
