package com.moneyclaritytech.vaanistudio.audio

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.util.concurrent.Future
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

class VaaniAudioModule : Module() {
  private val executor = Executors.newSingleThreadExecutor()
  private val recording = AtomicBoolean(false)
  private var recordingTask: Future<*>? = null
  private var audioRecord: AudioRecord? = null
  private var outputFile: File? = null
  private var recordingStartedAt = 0L
  private var sampleRate = 24_000
  @Volatile private var latestRms = 0.0
  @Volatile private var peak = 0.0
  @Volatile private var clippedSamples = 0L
  @Volatile private var totalSamples = 0L
  private var mediaPlayer: MediaPlayer? = null
  @Volatile private var playerPrepared = false

  override fun definition() = ModuleDefinition {
    Name("VaaniAudio")

    AsyncFunction("startRecording") { fileUri: String ->
      startRecording(fileUri)
    }

    AsyncFunction("stopRecording") {
      stopRecording()
    }

    AsyncFunction("getRecordingStatus") {
      recordingStatus()
    }

    AsyncFunction("inspectWav") { fileUri: String ->
      inspectWav(fileFor(fileUri))
    }

    AsyncFunction("sha256File") { fileUri: String ->
      sha256(fileFor(fileUri))
    }

    AsyncFunction("startPlayback") { fileUri: String ->
      startPlayback(fileUri)
    }

    AsyncFunction("pausePlayback") {
      mediaPlayer?.takeIf { playerPrepared && it.isPlaying }?.pause()
      playbackStatus()
    }

    AsyncFunction("resumePlayback") {
      mediaPlayer?.takeIf { playerPrepared && !it.isPlaying }?.start()
      playbackStatus()
    }

    AsyncFunction("stopPlayback") {
      releasePlayer()
      playbackStatus()
    }

    AsyncFunction("getPlaybackStatus") {
      playbackStatus()
    }
  }

  @Suppress("MissingPermission")
  private fun startRecording(fileUri: String): Map<String, Any> {
    if (recording.get()) throw IllegalStateException("A recording is already in progress")

    releasePlayer()
    val file = fileFor(fileUri).also { target ->
      target.parentFile?.mkdirs()
      if (target.exists()) target.delete()
    }
    outputFile = file

    val selectedRate = listOf(24_000, 48_000).firstOrNull { rate ->
      AudioRecord.getMinBufferSize(
        rate,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT
      ) > 0
    } ?: throw IllegalStateException("This phone does not expose a compatible microphone format")

    sampleRate = selectedRate
    val minimum = AudioRecord.getMinBufferSize(
      sampleRate,
      AudioFormat.CHANNEL_IN_MONO,
      AudioFormat.ENCODING_PCM_16BIT
    )
    val bufferBytes = max(minimum * 2, sampleRate / 2)

    val recorder = AudioRecord(
      MediaRecorder.AudioSource.VOICE_RECOGNITION,
      sampleRate,
      AudioFormat.CHANNEL_IN_MONO,
      AudioFormat.ENCODING_PCM_16BIT,
      bufferBytes
    )
    if (recorder.state != AudioRecord.STATE_INITIALIZED) {
      recorder.release()
      throw IllegalStateException("The microphone could not be initialized")
    }

    latestRms = 0.0
    peak = 0.0
    clippedSamples = 0
    totalSamples = 0
    audioRecord = recorder
    RandomAccessFile(file, "rw").use { it.write(ByteArray(44)) }
    try {
      recorder.startRecording()
    } catch (error: Exception) {
      recorder.release()
      audioRecord = null
      file.delete()
      throw IllegalStateException("The microphone could not start", error)
    }
    recording.set(true)
    recordingStartedAt = System.currentTimeMillis()

    recordingTask = executor.submit {
      captureLoop(recorder, bufferBytes)
    }
    return recordingStatus()
  }

  private fun captureLoop(recorder: AudioRecord, bufferBytes: Int) {
    val samples = ShortArray(bufferBytes / 2)
    val file = outputFile ?: return
    try {
      RandomAccessFile(file, "rw").use { writer ->
        writer.seek(44)
        while (recording.get()) {
          val count = recorder.read(samples, 0, samples.size, AudioRecord.READ_BLOCKING)
          if (count <= 0) continue

          var sumSquares = 0.0
          var blockPeak = 0
          var blockClipped = 0L
          val bytes = ByteBuffer.allocate(count * 2).order(ByteOrder.LITTLE_ENDIAN)
          for (index in 0 until count) {
            val value = samples[index].toInt()
            val magnitude = abs(value)
            sumSquares += value.toDouble() * value.toDouble()
            blockPeak = max(blockPeak, magnitude)
            if (magnitude >= 32_600) blockClipped++
            bytes.putShort(samples[index])
          }
          writer.write(bytes.array())
          latestRms = sqrt(sumSquares / count) / 32_768.0
          peak = max(peak, blockPeak / 32_768.0)
          clippedSamples += blockClipped
          totalSamples += count
        }
      }
    } finally {
      recording.set(false)
      try { recorder.stop() } catch (_: Exception) {}
      recorder.release()
      audioRecord = null
      outputFile?.let { patchWavHeader(it, sampleRate, 1, 16) }
    }
  }

  private fun stopRecording(): Map<String, Any> {
    if (recording.getAndSet(false)) {
      try { audioRecord?.stop() } catch (_: Exception) {}
      try { recordingTask?.get(4, TimeUnit.SECONDS) } catch (_: Exception) {}
    }
    val file = outputFile ?: throw IllegalStateException("No recording is available")
    val status = recordingStatus().toMutableMap()
    status["fileUri"] = Uri.fromFile(file).toString()
    status["bytes"] = file.length()
    return status
  }

  private fun recordingStatus(): Map<String, Any> {
    val duration = if (recordingStartedAt == 0L) 0L else {
      if (recording.get()) {
        System.currentTimeMillis() - recordingStartedAt
      } else {
        totalSamples * 1_000L / sampleRate
      }
    }
    val clipped = if (totalSamples == 0L) 0.0 else clippedSamples * 100.0 / totalSamples
    return mapOf(
      "isRecording" to recording.get(),
      "durationMs" to duration,
      "sampleRate" to sampleRate,
      "rms" to latestRms,
      "peak" to peak,
      "clippedPercent" to clipped
    )
  }

  private fun startPlayback(fileUri: String): Map<String, Any> {
    releasePlayer()
    val context = appContext.reactContext
      ?: throw IllegalStateException("Android context is unavailable")
    val player = MediaPlayer()
    mediaPlayer = player
    player.setDataSource(context, Uri.parse(fileUri))
    player.setOnCompletionListener { completed ->
      try { completed.seekTo(0) } catch (_: Exception) {}
    }
    player.prepare()
    playerPrepared = true
    player.start()
    return playbackStatus()
  }

  private fun playbackStatus(): Map<String, Any> {
    val player = mediaPlayer
    if (player == null || !playerPrepared) {
      return mapOf(
        "isLoaded" to false,
        "isPlaying" to false,
        "positionMs" to 0,
        "durationMs" to 0
      )
    }
    return try {
      mapOf(
        "isLoaded" to true,
        "isPlaying" to player.isPlaying,
        "positionMs" to player.currentPosition,
        "durationMs" to player.duration
      )
    } catch (_: Exception) {
      mapOf(
        "isLoaded" to false,
        "isPlaying" to false,
        "positionMs" to 0,
        "durationMs" to 0
      )
    }
  }

  private fun releasePlayer() {
    val player = mediaPlayer
    mediaPlayer = null
    playerPrepared = false
    try { player?.stop() } catch (_: Exception) {}
    try { player?.release() } catch (_: Exception) {}
  }

  private fun patchWavHeader(file: File, rate: Int, channels: Int, bits: Int) {
    if (!file.exists() || file.length() < 44) return
    val dataSize = file.length() - 44
    val byteRate = rate * channels * bits / 8
    val blockAlign = channels * bits / 8
    val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
    header.put("RIFF".toByteArray(Charsets.US_ASCII))
    header.putInt((36 + dataSize).toInt())
    header.put("WAVE".toByteArray(Charsets.US_ASCII))
    header.put("fmt ".toByteArray(Charsets.US_ASCII))
    header.putInt(16)
    header.putShort(1)
    header.putShort(channels.toShort())
    header.putInt(rate)
    header.putInt(byteRate)
    header.putShort(blockAlign.toShort())
    header.putShort(bits.toShort())
    header.put("data".toByteArray(Charsets.US_ASCII))
    header.putInt(dataSize.toInt())
    RandomAccessFile(file, "rw").use { writer ->
      writer.seek(0)
      writer.write(header.array())
    }
  }

  private fun inspectWav(file: File): Map<String, Any> {
    if (!file.exists() || file.length() < 44) return invalidWav("The file is too small")
    return try {
      RandomAccessFile(file, "r").use { reader ->
        val riff = ByteArray(4).also { reader.readFully(it) }.toString(Charsets.US_ASCII)
        readIntLE(reader)
        val wave = ByteArray(4).also { reader.readFully(it) }.toString(Charsets.US_ASCII)
        if (riff != "RIFF" || wave != "WAVE") return invalidWav("Not a RIFF/WAVE file")

        var format = 0
        var channels = 0
        var rate = 0
        var bits = 0
        var dataOffset = 0L
        var dataBytes = 0L
        while (reader.filePointer + 8 <= reader.length()) {
          val id = ByteArray(4).also { reader.readFully(it) }.toString(Charsets.US_ASCII)
          val size = readIntLE(reader).toLong() and 0xffffffffL
          val start = reader.filePointer
          if (id == "fmt " && size >= 16) {
            format = readShortLE(reader)
            channels = readShortLE(reader)
            rate = readIntLE(reader)
            readIntLE(reader)
            readShortLE(reader)
            bits = readShortLE(reader)
          } else if (id == "data") {
            dataOffset = start
            dataBytes = minOf(size, reader.length() - start)
          }
          reader.seek(minOf(reader.length(), start + size + (size and 1L)))
        }

        if (dataBytes <= 0 || channels <= 0 || rate <= 0 || bits <= 0) {
          return invalidWav("The WAV header is incomplete")
        }
        val duration = dataBytes * 8_000L / (rate.toLong() * channels * bits)
        val reason = when {
          format != 1 -> "Only uncompressed PCM WAV is supported"
          bits != 16 -> "Only 16-bit PCM WAV is supported"
          else -> ""
        }
        mapOf(
          "valid" to (reason.isEmpty()),
          "format" to format,
          "channels" to channels,
          "sampleRate" to rate,
          "bitsPerSample" to bits,
          "dataOffset" to dataOffset,
          "dataBytes" to dataBytes,
          "durationMs" to duration,
          "reason" to reason
        )
      }
    } catch (error: Exception) {
      invalidWav(error.message ?: "The WAV file could not be read")
    }
  }

  private fun invalidWav(reason: String) = mapOf(
    "valid" to false,
    "format" to 0,
    "channels" to 0,
    "sampleRate" to 0,
    "bitsPerSample" to 0,
    "dataOffset" to 0,
    "dataBytes" to 0,
    "durationMs" to 0,
    "reason" to reason
  )

  private fun sha256(file: File): String {
    if (!file.exists()) throw IllegalArgumentException("File does not exist: ${file.name}")
    val digest = MessageDigest.getInstance("SHA-256")
    file.inputStream().buffered().use { input ->
      val buffer = ByteArray(1024 * 1024)
      while (true) {
        val count = input.read(buffer)
        if (count < 0) break
        if (count > 0) digest.update(buffer, 0, count)
      }
    }
    return digest.digest().joinToString("") { "%02x".format(it) }
  }

  private fun fileFor(uriOrPath: String): File {
    return if (uriOrPath.startsWith("file:")) {
      File(Uri.parse(uriOrPath).path ?: throw IllegalArgumentException("Invalid file URI"))
    } else {
      File(uriOrPath)
    }
  }

  private fun readShortLE(reader: RandomAccessFile): Int {
    val low = reader.readUnsignedByte()
    val high = reader.readUnsignedByte()
    return low or (high shl 8)
  }

  private fun readIntLE(reader: RandomAccessFile): Int {
    val b0 = reader.readUnsignedByte()
    val b1 = reader.readUnsignedByte()
    val b2 = reader.readUnsignedByte()
    val b3 = reader.readUnsignedByte()
    return b0 or (b1 shl 8) or (b2 shl 16) or (b3 shl 24)
  }
}
