import { registerRootComponent } from "expo";

import LaunchGuard from "./LaunchGuard";

registerRootComponent(LaunchGuard);
