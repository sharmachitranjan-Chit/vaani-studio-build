"use strict";

const fs = require("bare-fs");
const path = require("bare-path");
const b4a = require("b4a");
const ONNXTTS = require("@qvac/tts-onnx");

const { IPC } = BareKit;
const OUTPUT_RATE = 24_000;
const MODEL_FILES = {
  tokenizer: "tokenizer.json",
  speechEncoder: "speech_encoder.onnx",
  embedTokens: "embed_tokens.onnx",
  conditionalDecoder: "conditional_decoder.onnx",
  languageModel: "language_model.onnx",
};

let inputBuffer = "";
let commandQueue = Promise.resolve();
let model = null;
let modelLanguage = null;
let activeJobId = null;
let cancelRequested = false;

function send(message) {
  IPC.write(b4a.from(`${JSON.stringify(message)}\n`));
}

function sendError(id, error, code = "ENGINE_ERROR") {
  const message = error && error.message ? error.message : String(error);
  send({ type: "error", id, code, message });
}

IPC.on("data", (chunk) => {
  inputBuffer += b4a.toString(chunk);
  while (true) {
    const newline = inputBuffer.indexOf("\n");
    if (newline < 0) break;
    const line = inputBuffer.slice(0, newline).trim();
    inputBuffer = inputBuffer.slice(newline + 1);
    if (!line) continue;

    let command;
    try {
      command = JSON.parse(line);
    } catch (error) {
      sendError(
        null,
        new Error("The app sent an unreadable command"),
        "BAD_COMMAND",
      );
      continue;
    }

    if (command.type === "cancel") {
      cancel(command).catch((error) => sendError(command.id, error));
    } else {
      commandQueue = commandQueue
        .then(() => handle(command))
        .catch((error) => sendError(command.id, error));
    }
  }
});

async function handle(command) {
  switch (command.type) {
    case "ping":
      send({ type: "pong", id: command.id });
      break;
    case "init":
      await initialize(command);
      break;
    case "generate":
      await generate(command);
      break;
    case "shutdown":
      await destroyModel();
      send({ type: "shutdown", id: command.id });
      break;
    default:
      throw new Error(`Unknown engine command: ${command.type}`);
  }
}

async function initialize(command) {
  const { id, modelDir, voicePath, language = "hi", numThreads = 4 } = command;
  if (!modelDir || !voicePath)
    throw new Error("Model and voice paths are required");

  await destroyModel();
  send({
    type: "status",
    id,
    stage: "reading_voice",
    message: "Preparing your voice sample…",
  });
  const referenceAudio = readReferenceAudio(voicePath);
  if (referenceAudio.length < OUTPUT_RATE * 2) {
    throw new Error(
      "The voice sample needs at least 2 seconds of clear speech",
    );
  }

  const files = { modelDir };
  for (const [key, filename] of Object.entries(MODEL_FILES)) {
    const filePath = path.join(modelDir, filename);
    if (!fs.existsSync(filePath))
      throw new Error(`Missing model file: ${filename}`);
    files[key] = filePath;
  }

  send({
    type: "status",
    id,
    stage: "loading_model",
    message: "Opening the offline voice model…",
  });
  model = new ONNXTTS({
    files,
    engine: "chatterbox",
    referenceAudio,
    config: { language, useGPU: false },
    lazySessionLoading: true,
    numThreads: Math.max(1, Math.min(6, Number(numThreads) || 4)),
    opts: { stats: true },
    exclusiveRun: true,
    logger: {
      debug() {},
      info() {},
      warn(message) {
        send({ type: "log", level: "warn", message: String(message) });
      },
      error(message) {
        send({ type: "log", level: "error", message: String(message) });
      },
    },
  });
  await model.load();
  modelLanguage = language;
  send({
    type: "ready",
    id,
    sampleCount: referenceAudio.length,
    sampleSeconds: referenceAudio.length / OUTPUT_RATE,
  });
}

async function generate(command) {
  const { id, text, outputPath, language = "hi", locale = "hi-IN" } = command;
  if (!model)
    throw new Error("Set up the offline model and voice before generating");
  if (activeJobId)
    throw new Error("Another audio file is already being generated");
  const cleaned = String(text || "")
    .replace(/\s+/g, " ")
    .trim();
  if (!cleaned) throw new Error("Enter some text first");
  if (cleaned.length > 8_000)
    throw new Error("Use 8,000 characters or fewer per audio file");
  if (!outputPath) throw new Error("An output path is required");

  activeJobId = id;
  cancelRequested = false;
  let writer = null;
  let totalPcmBytes = 0;
  let chunks = 0;
  const startedAt = Date.now();

  try {
    if (language !== modelLanguage) {
      send({
        type: "status",
        id,
        stage: "switching_language",
        message: "Switching pronunciation…",
      });
      await model.reload({ language, useGPU: false });
      modelLanguage = language;
    }

    const parent = path.dirname(outputPath);
    if (!fs.existsSync(parent)) fs.mkdirSync(parent, { recursive: true });
    writer = fs.openSync(outputPath, "w");
    fs.writeSync(writer, b4a.alloc(44));
    send({
      type: "progress",
      id,
      stage: "generating",
      progress: 0.02,
      chunks: 0,
    });

    const response = await model.run({
      input: cleaned,
      type: "text",
      streamOutput: true,
      locale,
      maxChunkScalars: language === "hi" ? 180 : 220,
    });

    await response
      .onUpdate((data) => {
        if (!data || !data.outputArray) return;
        if (cancelRequested) return;
        const pcm = outputToPcmBytes(data.outputArray);
        if (!pcm.byteLength) return;
        fs.writeSync(writer, pcm);
        totalPcmBytes += pcm.byteLength;
        chunks += 1;
        const progress =
          data.chunkIndex == null
            ? Math.min(0.92, 0.08 + chunks * 0.12)
            : Math.min(0.94, 0.1 + Number(data.chunkIndex + 1) * 0.12);
        send({
          type: "progress",
          id,
          stage: "generating",
          progress,
          chunks,
          sentence: data.sentenceChunk || "",
        });
      })
      .await();

    if (cancelRequested) throw new CancelledError();
    if (totalPcmBytes === 0) throw new Error("The model returned no audio");

    const header = wavHeader(totalPcmBytes, OUTPUT_RATE, 1, 16);
    fs.writeSync(writer, header, 0, header.byteLength, 0);
    fs.closeSync(writer);
    writer = null;

    const durationMs = Math.round((totalPcmBytes / 2 / OUTPUT_RATE) * 1_000);
    send({
      type: "complete",
      id,
      outputPath,
      durationMs,
      bytes: totalPcmBytes + 44,
      chunks,
      elapsedMs: Date.now() - startedAt,
      stats: response.stats || null,
    });
  } catch (error) {
    if (writer != null) {
      try {
        fs.closeSync(writer);
      } catch (_) {}
    }
    try {
      if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
    } catch (_) {}
    if (error instanceof CancelledError || cancelRequested) {
      send({ type: "cancelled", id });
    } else {
      sendError(id, error);
    }
  } finally {
    activeJobId = null;
    cancelRequested = false;
  }
}

async function cancel(command) {
  cancelRequested = true;
  if (model && activeJobId) {
    try {
      await model.cancel();
    } catch (_) {}
  }
  send({ type: "cancel_ack", id: command.id, jobId: activeJobId });
}

async function destroyModel() {
  if (!model) return;
  const previous = model;
  model = null;
  modelLanguage = null;
  try {
    await previous.cancel();
  } catch (_) {}
  try {
    await previous.destroy();
  } catch (_) {}
}

function readReferenceAudio(filePath) {
  const file = fs.readFileSync(filePath);
  if (
    file.byteLength < 44 ||
    ascii(file, 0, 4) !== "RIFF" ||
    ascii(file, 8, 12) !== "WAVE"
  ) {
    throw new Error("Voice sample must be an uncompressed WAV file");
  }

  let offset = 12;
  let format = null;
  let dataOffset = -1;
  let dataSize = 0;
  while (offset + 8 <= file.byteLength) {
    const id = ascii(file, offset, offset + 4);
    const size = readU32(file, offset + 4);
    const start = offset + 8;
    if (id === "fmt " && size >= 16) {
      format = {
        audioFormat: readU16(file, start),
        channels: readU16(file, start + 2),
        sampleRate: readU32(file, start + 4),
        bits: readU16(file, start + 14),
      };
    } else if (id === "data") {
      dataOffset = start;
      dataSize = Math.min(size, file.byteLength - start);
    }
    offset = start + size + (size % 2);
  }

  if (!format || dataOffset < 0)
    throw new Error("Voice WAV header is incomplete");
  if (format.audioFormat !== 1 || format.bits !== 16) {
    throw new Error("Voice sample must be 16-bit PCM WAV");
  }
  if (format.channels < 1 || format.channels > 2) {
    throw new Error("Voice sample must be mono or stereo");
  }
  if (format.sampleRate < 8_000 || format.sampleRate > 96_000) {
    throw new Error("Voice sample has an unsupported sample rate");
  }

  const frames = Math.floor(dataSize / (2 * format.channels));
  const mono = new Float32Array(frames);
  for (let frame = 0; frame < frames; frame++) {
    let sum = 0;
    for (let channel = 0; channel < format.channels; channel++) {
      const position = dataOffset + (frame * format.channels + channel) * 2;
      const unsigned = file[position] | (file[position + 1] << 8);
      const signed = unsigned & 0x8000 ? unsigned - 0x10000 : unsigned;
      sum += signed / 32768;
    }
    mono[frame] = sum / format.channels;
  }

  const resampled =
    format.sampleRate === OUTPUT_RATE
      ? mono
      : resampleLinear(mono, format.sampleRate, OUTPUT_RATE);
  return trimSilence(resampled, OUTPUT_RATE, 0.006, 0.12, 10);
}

function resampleLinear(input, sourceRate, targetRate) {
  const length = Math.max(
    1,
    Math.round((input.length * targetRate) / sourceRate),
  );
  const output = new Float32Array(length);
  const ratio = sourceRate / targetRate;
  for (let index = 0; index < length; index++) {
    const position = index * ratio;
    const left = Math.floor(position);
    const right = Math.min(input.length - 1, left + 1);
    const fraction = position - left;
    output[index] = input[left] * (1 - fraction) + input[right] * fraction;
  }
  return output;
}

function trimSilence(input, rate, threshold, paddingSeconds, maxSeconds) {
  let start = 0;
  let end = input.length - 1;
  while (start < input.length && Math.abs(input[start]) < threshold) start++;
  while (end > start && Math.abs(input[end]) < threshold) end--;
  const padding = Math.round(paddingSeconds * rate);
  start = Math.max(0, start - padding);
  end = Math.min(input.length, end + padding + 1);
  if (end - start > maxSeconds * rate) end = start + maxSeconds * rate;
  return input.slice(start, end);
}

function outputToPcmBytes(output) {
  if (output instanceof ArrayBuffer) return b4a.from(new Uint8Array(output));
  if (ArrayBuffer.isView(output)) {
    return b4a.from(
      new Uint8Array(output.buffer, output.byteOffset, output.byteLength),
    );
  }
  if (Array.isArray(output)) {
    const bytes = b4a.alloc(output.length * 2);
    for (let index = 0; index < output.length; index++) {
      const value = Math.max(
        -32768,
        Math.min(32767, Number(output[index]) || 0),
      );
      bytes[index * 2] = value & 0xff;
      bytes[index * 2 + 1] = (value >> 8) & 0xff;
    }
    return bytes;
  }
  return b4a.alloc(0);
}

function wavHeader(dataBytes, rate, channels, bits) {
  const header = b4a.alloc(44);
  writeAscii(header, 0, "RIFF");
  writeU32(header, 4, 36 + dataBytes);
  writeAscii(header, 8, "WAVE");
  writeAscii(header, 12, "fmt ");
  writeU32(header, 16, 16);
  writeU16(header, 20, 1);
  writeU16(header, 22, channels);
  writeU32(header, 24, rate);
  writeU32(header, 28, (rate * channels * bits) / 8);
  writeU16(header, 32, (channels * bits) / 8);
  writeU16(header, 34, bits);
  writeAscii(header, 36, "data");
  writeU32(header, 40, dataBytes);
  return header;
}

function ascii(buffer, start, end) {
  return b4a.toString(buffer.subarray(start, end), "ascii");
}

function readU16(buffer, offset) {
  return buffer[offset] | (buffer[offset + 1] << 8);
}

function readU32(buffer, offset) {
  return (
    (buffer[offset] |
      (buffer[offset + 1] << 8) |
      (buffer[offset + 2] << 16) |
      (buffer[offset + 3] << 24)) >>>
    0
  );
}

function writeAscii(buffer, offset, value) {
  for (let index = 0; index < value.length; index++)
    buffer[offset + index] = value.charCodeAt(index);
}

function writeU16(buffer, offset, value) {
  buffer[offset] = value & 0xff;
  buffer[offset + 1] = (value >>> 8) & 0xff;
}

function writeU32(buffer, offset, value) {
  buffer[offset] = value & 0xff;
  buffer[offset + 1] = (value >>> 8) & 0xff;
  buffer[offset + 2] = (value >>> 16) & 0xff;
  buffer[offset + 3] = (value >>> 24) & 0xff;
}

class CancelledError extends Error {}

send({ type: "booted", version: 1 });
